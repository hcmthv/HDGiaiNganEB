using System;
using System.Net.Http;

using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;


namespace CronJobService
{
    public class Worker : BackgroundService
    {
        private readonly IOptions<AppConfig> _appConfig;
        private readonly ILogger<Worker> _logger;
        private Timer _timer;

        public Worker(ILogger<Worker> logger, IOptions<AppConfig> appConfig)
        {
            _logger = logger;
            _appConfig = appConfig;
        }

        public async Task<string> ExecuteService(string url = null)
        {
            var res = RequestHTTP.Intance.httpGet(url);
            string apiResponse = string.Empty;
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(url))
                {
                    apiResponse = await response.Content.ReadAsStringAsync();
                }
            }
            return apiResponse;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                foreach (var job in _appConfig.Value.Jobs)
                {
                    _logger.LogInformation($"Worker running at { DateTimeOffset.Now}: {job.Service}");
                    var resData = ExecuteService(job.url);
                    _logger.LogInformation($"Response from server: {job.Service} -> Message: {resData}");
                    await Task.Delay(job.Seconds, stoppingToken);
                }               
              
            }
        }


    }
}
