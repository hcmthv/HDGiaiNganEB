﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace CronJobService
{
    public class RequestHTTP
    {
        public static readonly RequestHTTP Intance = new RequestHTTP();
        public string httpGet(string url)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            //request.Method = "HEAD";
            //request.AllowAutoRedirect = false;

            request.Credentials = CredentialCache.DefaultCredentials;
            // Ignore Certificate validation failures (aka untrusted certificate + certificate chains)
            ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream resStream = response.GetResponseStream();
            string responseFromServer;
            using (StreamReader reader = new StreamReader(resStream))
            {
                responseFromServer = reader.ReadToEnd();
            }

            return responseFromServer;
        }
    }
}
