﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CronJobService
{
    public class ProcessFile : BackgroundService
    {
        private readonly ILogger<Worker> _logger;

        public ProcessFile(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
               _logger.LogInformation("Process running at: {time} - SendFile", DateTimeOffset.Now);

               string url = @"http://localhost:5000/api/thongtinquytrinh/xl"; 
               var res = RequestHTTP.Intance.httpGet(url);
               string apiResponse = string.Empty;
               using (var httpClient = new HttpClient())
               {
                   using (var response = await httpClient.GetAsync(url))
                   {
                       apiResponse = await response.Content.ReadAsStringAsync();                     
                   }
               }

               /*
               http://localhost:5000/api/thongtinquytrinh/kq*/
                await Task.Delay(2000, stoppingToken);
            }
        }
    }
}
