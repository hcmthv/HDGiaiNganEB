﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CronJobService
{
    public class AppConfig
    {
        public string TextToPrint { get; set; }
        public List<JobSchedule> Jobs { get; set; }
        public AppConfig() {
            Jobs = new List<JobSchedule>();
        }
    }

    public class JobSchedule
    {
        public string Service { get; set; }
        public int Seconds { get; set; }
        public string url { get; set; }
    }
}
