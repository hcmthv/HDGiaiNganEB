﻿using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaiNganAPI.Interfaces.Clients
{
    public interface IThongTinQuyTrinhService
    {
        Task<List<ThongTinQuyTrinhModel>> GetTCThongTinChungTu_Verify();

        Task<List<ThongTinQuyTrinhModel>> GetTCThongTinChungTu_Process();
   
        Task<int> CapNhatIDQLYC(int l_id, int? l_ID_THONGTIN = null);
        Task<int> CapNhatTTChuTaiKhoan(int l_id, string l_TrangThai = null, string l_CTK_MaSoThue = null, string l_ChiNhanh = null);

        Task<int> CapNhatSoTaiKhoan(int? l_IDChuTaiKhoan = null);
        Task<int> CapNhatTaiLieu(int? l_id, int? l_IDChuTaiKhoan = null);

        Task<int> ProcessSql_BC(string status = null, ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null);
        Task<int> ProcessSql(string status = null, ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null);
        Task<int> InsertThongTinQuyTrinh(ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null, string webRootPath = null);

        Task<int> UpdateThongTinQuyTrinh(ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null, string webRootPath = null);

    }
}
