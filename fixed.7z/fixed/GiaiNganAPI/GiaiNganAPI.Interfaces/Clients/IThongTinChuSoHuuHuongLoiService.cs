﻿using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaiNganAPI.Interfaces.Clients
{
    public interface IThongTinChuSoHuuHuongLoiService
    {
        Task<List<ThongTinChuSoHuuHuongLoiModel>> GetThongTinChuSoHuuHuongLoi(int? l_Id = null);
        Task<int> ProcessSql(string status = null, ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null);

        Task<int> InsertThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null);
        Task<int> UpdateThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null);
        Task<int> DeleteThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null);
    }
}
