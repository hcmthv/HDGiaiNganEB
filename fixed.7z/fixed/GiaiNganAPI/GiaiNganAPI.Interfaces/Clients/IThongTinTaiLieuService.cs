﻿using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaiNganAPI.Interfaces.Clients
{
    public interface IThongTinTaiLieuService
    {
        Task<List<ThongTinTaiLieuModel>> GetThongTinTaiLieu(int? l_Id = null, int? l_UuTien = null);
        Task<int> ProcessSql(string status = null, ThongTinTaiLieuModel pThongTinChuTaiKhoan = null);

        Task<int> InsertThongTinTaiLieu(ThongTinTaiLieuModel pThongTinChuTaiKhoan = null);
        Task<int> UpdateThongTinTaiLieu(ThongTinTaiLieuModel pThongTinChuTaiKhoan = null);
        Task<int> DeleteThongTinTaiLieu(ThongTinTaiLieuModel pThongTinChuTaiKhoan = null);
    }
}
