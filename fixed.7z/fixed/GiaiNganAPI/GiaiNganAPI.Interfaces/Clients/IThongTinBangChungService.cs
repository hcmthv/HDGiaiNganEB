﻿using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaiNganAPI.Interfaces.Clients
{
    public interface IThongTinBangChungService
    {
        Task<List<ThongTinBangChungModel>> GetID_QLYCThongTinBangChung(int? l_ID_QLYC = null);
        Task<List<ThongTinBangChungModel>> GetThongTinBangChung(int? l_Id = null);
        Task<int> ProcessSql(string status = null, ThongTinBangChungModel pThongTinChuTaiKhoan = null);

        Task<int> InsertThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null);
        Task<int> UpdateThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null);
        Task<int> DeleteThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null);

    }
}
