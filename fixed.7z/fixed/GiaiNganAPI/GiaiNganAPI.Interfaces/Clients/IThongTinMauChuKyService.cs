﻿using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaiNganAPI.Interfaces.Clients
{
    public interface IThongTinMauChuKyService
    {
        Task<List<ThongTinMauChuKyModel>> GetThongTinMauChuKy(int? l_Id = null);
        Task<int> ProcessSql(string status = null, ThongTinMauChuKyModel pThongTinChuTaiKhoan = null);

        Task<int> InsertThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null);
        Task<int> UpdateThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null);
        Task<int> DeleteThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null);

    }
}
