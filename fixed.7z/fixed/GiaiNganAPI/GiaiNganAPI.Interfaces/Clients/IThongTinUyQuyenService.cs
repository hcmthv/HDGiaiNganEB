﻿using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaiNganAPI.Interfaces.Clients
{
    public interface IThongTinUyQuyenService
    {
        Task<List<ThongTinUyQuyenModel>> GetThongTinUyQuyen(int? l_Id = null);
        Task<int> ProcessSql(string status = null, ThongTinUyQuyenModel pThongTinChuTaiKhoan = null);

        Task<int> InsertThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null);
        Task<int> UpdateThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null);
        Task<int> DeleteThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null);

    }
}
