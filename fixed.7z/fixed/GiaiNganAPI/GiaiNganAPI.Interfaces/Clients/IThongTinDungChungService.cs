﻿using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaiNganAPI.Interfaces.Clients
{
    public interface IThongTinDungChungService
    {
        Task<List<ThongTinChiNhanhModel>> GetThongTinChiNhanh(int? l_Id = null);
        Task<List<ThongTinSoTaiKhoanModel>> GetThongTinCIF(int? l_Id = null, string l_MaChiNhanh = null);
        Task<List<ThongTinSoTaiKhoanModel>> GetThongTinTienTe(int? l_Id = null, string l_MaChiNhanh = null);
        Task<List<ThongTinSoTaiKhoanModel>> GetThongTinSoTaiKhoan(int? l_Id = null, string l_MaChiNhanh = null, string l_TienTe = null, string l_CIF = null);
        Task<List<ThongTinThamSoModel>> GetThongTinThamSo(int? l_Id = null, string l_nhom = null);
        Task<List<ThongTinTinhModel>> GetThongTinTinh(int? l_Id = null);
        Task<List<ThongTinHuyenModel>> GetThongTinHuyen(int? l_PROVINCE_ID = null);
        Task<List<ThongTinXaModel>> GetThongTinXa(int? l_DISTRICT_ID = null);

        Task<List<ThongTinDuongModel>> GetThongTinDuong(int? l_PROVINCE_ID = null, int? l_DISTRICT_ID = null);
    }
}
