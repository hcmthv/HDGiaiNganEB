﻿using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaiNganAPI.Interfaces.Clients
{
    public interface IThongTinChuTaiKhoanService
    {
        Task<List<ThongTinChuTaiKhoanModel>> GetTCThongTinChuTaiKhoan();
        Task<List<ThongTinChuTaiKhoanModel>> GetThongTinChuTaiKhoan(int? l_Id = null);

        Task<List<ThongTinChuTaiKhoanModel>> GetThongTinChuSoTaiKhoan(int? l_Id = null, string l_SoTaiKhoan = null);

        Task<int> ProcessSql(string status = null, ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null);
        Task<int> InsertThongTinChuTaiKhoan(ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null);
        Task<int> UpdateThongTinChuTaiKhoan(ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null);
        Task<int> DeleteThongTinChuTaiKhoan(ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null);
    }
}
