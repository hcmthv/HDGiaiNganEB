﻿using Newtonsoft.Json;

namespace GiaiNganAPI.Models
{
    public class ErrorResponseModel
    {
        [JsonProperty("error")]
        public ErrorModel Error { get; set; }
    }

    public class ErrorModel
    {
        [JsonProperty("code")]
        public int ErrorCode { get; set; }
        [JsonProperty("message")]
        public string ErrorMessage { get; set; }
    }
}
