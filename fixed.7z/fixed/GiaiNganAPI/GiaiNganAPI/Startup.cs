﻿using GiaiNganAPI.Attribute;
using GiaiNganAPI.Interfaces.Clients;
using GiaiNganAPI.Interfaces.System;
using GiaiNganAPI.Services.System;
using GiaNganAPI.Services.Clients;
using GiaNganAPI.Services.Common.Upload;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace GiaiNganAPI
{
    public class Startup
    {
        public Startup(IHostingEnvironment hostEnvironment, IConfiguration configuration)
        {
            HostingEnvironment = hostEnvironment;
            Configuration = configuration;
        }


        private IHostingEnvironment HostingEnvironment { get; }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            /* Authentication */
            services.AddCors(config =>
            {
                var policy = new CorsPolicy();
                policy.Headers.Add("*");
                policy.Methods.Add("*");
                policy.Origins.Add("*");
                policy.SupportsCredentials = true;
                config.AddPolicy("policy", policy);
            });

            services.AddAuthorization(auth =>
            {
                auth.AddPolicy("Bearer", new AuthorizationPolicyBuilder()
                    .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme)
                    .RequireAuthenticatedUser().Build());
            });

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Configuration["Jwt:Issuer"],
                    ValidAudience = Configuration["Jwt:Issuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                };
            });

            services.AddMvc()
                .AddJsonOptions(options =>
                {
                    options.SerializerSettings.ContractResolver = new JsonLowercaseContractResolver();
                });

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            services.AddSingleton(provider => Configuration);
            /* Get sql Connection.
            string conn = Configuration.GetConnectionString("HDConnection");
            services.Configure<AppSettings>(Configuration.GetSection("ConnectionStrings")); */

            //upload
            services.AddTransient<IUploadService, LocalUploadService>();

            // Services
            services.AddTransient<IMasUserService, MasUserService>();
            services.AddTransient<IThongTinChuTaiKhoanService, ThongTinChuTaiKhoanService>();
            services.AddTransient<IThongTinChuSoHuuHuongLoiService, ThongTinChuSoHuuHuongLoiService>();
            services.AddTransient<IThongTinTaiLieuService, ThongTinTaiLieuService>();
            services.AddTransient<IThongTinDungChungService, ThongTinDungChungService>();
            services.AddTransient<IThongTinMauChuKyService, ThongTinMauChuKyService>();
            services.AddTransient<IThongTinUyQuyenService, ThongTinUyQuyenService>();
            services.AddTransient<IThongTinBangChungService, ThongTinBangChungService>();
            services.AddTransient<IThongTinQuyTrinhService, ThongTinQuyTrinhService>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddLog4Net();
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseStatusCodePagesWithReExecute("/Home/Error");
            }

            app.UseMiddleware<ApiErrorHandlingMiddleware>();

            app.UseCors("policy");
            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });

        }
    }
}
