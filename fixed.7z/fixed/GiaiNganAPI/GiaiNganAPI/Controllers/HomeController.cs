﻿using Microsoft.AspNetCore.Mvc;

namespace GiaiNganAPI.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}