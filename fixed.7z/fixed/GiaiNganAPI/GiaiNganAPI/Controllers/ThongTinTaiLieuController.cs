﻿
using GiaiNganAPI.Attribute;
using GiaiNganAPI.Config;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using GiaNganAPI.Services.Common.Upload;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GiaiNganAPI.Controllers
{

    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ThongTinTaiLieuController : Controller
    {
        private readonly IThongTinTaiLieuService _ThongTinTaiLieuService;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IUploadService _uploadService;

        public ThongTinTaiLieuController(IHostingEnvironment hostingEnvironment, IThongTinTaiLieuService ThongTinTaiLieuService, IUploadService uploadService)
        {
            _hostingEnvironment = hostingEnvironment;
            _ThongTinTaiLieuService = ThongTinTaiLieuService;
            _uploadService = uploadService;
        }

        [Authorize("Bearer")]
        [HttpPost("uploadFile")]
        public async Task<JsonResult> UploadFile([FromForm] ThongTinTaiLieuModel pThongTinTaiLieu = null)
        {
            if (!ModelState.IsValid)
            {
                return Json(new { success = false, data = new { message = "Không hợp lệ" } });
            }

            pThongTinTaiLieu.FileName = pThongTinTaiLieu.MyFile.FileName;
            pThongTinTaiLieu.FileType = pThongTinTaiLieu.MyFile.ContentType;
            var uploadResult = await _uploadService.UploadDocument(pThongTinTaiLieu.FileName, pThongTinTaiLieu.FileType, pThongTinTaiLieu.MyFile, $"document/{pThongTinTaiLieu.IDChuTaiKhoan}");
            if (!uploadResult.status)
            {
                return Json(new { ErrorCode.SAVE_FAILED, uploadResult.refMsg });
            }
            else
            {
                int iResult = -1;
                pThongTinTaiLieu.TenFile = pThongTinTaiLieu.MyFile.FileName;
                pThongTinTaiLieu.DuongDan = uploadResult.filePath;
                pThongTinTaiLieu.LoaiFile = pThongTinTaiLieu.FileType;
                pThongTinTaiLieu.DienGiaiFile = pThongTinTaiLieu.UuTien == 1 ? "Tập tin chính cần trình ký" : "Tập tin đính kèm";
                if (pThongTinTaiLieu.ID == 0)
                {
                    try
                    {                        
                        var o = _ThongTinTaiLieuService.InsertThongTinTaiLieu(pThongTinTaiLieu);
                        if (o.Status.ToString() != "Faulted")
                            iResult = 1;
                        else
                            throw o.Exception;
                    }
                    catch (Exception ex)
                    {
                        HandlingExceptionError exceptionError = new HandlingExceptionError();
                        exceptionError.OnException(ex);
                    }

                    if (iResult == -1)
                        return Json(new { success = false, data = new { message = "Dữ liệu chưa được thêm vào hệ thống!" } });

                    return Json(new { success = true, data = new { message = "Dữ liệu đã được thêm vào hệ thống" } });
                }
                else
                {
                    try
                    {
                        var o = _ThongTinTaiLieuService.UpdateThongTinTaiLieu(pThongTinTaiLieu);
                        if (o.Status.ToString() != "Faulted")
                            iResult = 1;
                        else
                            throw o.Exception;
                    }
                    catch (Exception ex)
                    {
                        HandlingExceptionError exceptionError = new HandlingExceptionError();
                        exceptionError.OnException(ex);
                    }

                    if (iResult == -1)
                        return Json(new { success = false, data = new { message = "Dữ liệu chưa được cập nhật vào hệ thống" } });

                    return Json(new { success = true, data = new { message = "Dữ liệu đã được cập nhật vào hệ thống" } });

                }
            }
        }
                       
        #region Thong tin chu tai khoan
        [HttpGet]
        [Authorize("Bearer")]
        [Route("detail/{id}")]
        public async Task<string> GetThongTinTaiLieu(int id)
        {
            var data = await _ThongTinTaiLieuService.GetThongTinTaiLieu(id);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpPost]
        [Authorize("Bearer")]
        [Route("insert")]
        public string InsertThongTinTaiLieuCate([FromBody] ThongTinTaiLieuModel pThongTinTaiLieu = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                var o = _ThongTinTaiLieuService.InsertThongTinTaiLieu(pThongTinTaiLieu);
                if (o.Status.ToString() != "Faulted")
                    iResult = 1;
                else
                    throw o.Exception;
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được thêm vào hệ thống!" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được thêm vào hệ thống" } });
        }

        [HttpPost]
        [Authorize("Bearer")]
        [Route("update")]
        public string UpdateThongTinTaiLieuCate([FromBody] ThongTinTaiLieuModel pThongTinTaiLieu = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                var o = _ThongTinTaiLieuService.UpdateThongTinTaiLieu(pThongTinTaiLieu);
                if (o.Status.ToString() != "Faulted")
                    iResult = 1;
                else
                    throw o.Exception;
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được cập nhật vào hệ thống" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được cập nhật vào hệ thống" } });
        }

        #endregion
    }
}