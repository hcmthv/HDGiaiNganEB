﻿
using GiaiNganAPI.Attribute;
using GiaiNganAPI.Config;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using GiaNganAPI.Services.Common.Upload;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GiaiNganAPI.Controllers
{

    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ThongTinQuyTrinhController : Controller
    {
        private readonly IThongTinTaiLieuService _ThongTinTaiLieuService;
        private readonly IThongTinBangChungService _thongtinChungService;
        private readonly IThongTinQuyTrinhService _thongtinQuyTrinhService;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IUploadService _uploadService;

        public ThongTinQuyTrinhController(IHostingEnvironment hostingEnvironment, IThongTinQuyTrinhService thongtinQuyTrinhService, IThongTinTaiLieuService ThongTinTaiLieuService,
             IThongTinBangChungService thongtinChungService, IUploadService uploadService)
        {
            _hostingEnvironment = hostingEnvironment;
            _thongtinQuyTrinhService = thongtinQuyTrinhService;
            _ThongTinTaiLieuService = ThongTinTaiLieuService;
            _thongtinChungService = thongtinChungService;
            _uploadService = uploadService;
        }

        #region Thong tin chu tai khoan
        [HttpGet]
        //[Authorize("Bearer")]
        [AllowAnonymous]
        [Route("list")]
        public async Task<JsonResult> GetThongTinQuyTrinh()
        {
            var data = await _thongtinQuyTrinhService.GetTCThongTinChungTu_Verify();
            if (data == null)
            {
                //return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
                return Json(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            //return Lib.Common.ConvertToBase64Encode(data);
            return Json(data);
        }

        [HttpGet]
        //[Authorize("Bearer")]
        [AllowAnonymous]
        [Route("xl")] // service 1
        public async Task<JsonResult> ProcessThongTinQuyTrinh()
        {
            List<ThongTinQuyTrinhModel> data = await _thongtinQuyTrinhService.GetTCThongTinChungTu_Verify();
            if (data == null)
            {
                return Json(new { success = false, data = new { message = "Chưa có dữ liệu cần chuyển đên hệ thống kiểm duyệt!" } });
            }

            int iResult = -1;
            try
            {
                if (data.Count > 0)
                {
                    foreach (var pThongTinQuyTrinh in data)
                    {
                        pThongTinQuyTrinh.MA_THONGTIN = Lib.Common.Instant.getMaYC();
                        var _webRootPath = _hostingEnvironment.ContentRootPath + $"\\upload\\document\\{pThongTinQuyTrinh.ID}";
                        var o = _thongtinQuyTrinhService.InsertThongTinQuyTrinh(pThongTinQuyTrinh, _webRootPath);
                        if (o.Status.ToString() != "Faulted")
                            iResult = 1;
                        else
                            throw o.Exception;
                    }
                }

            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Json(new { success = false, data = new { message = "Dữ liệu chưa được chuyển vào hệ thống kiểm duyệt!" } });

            return Json(new { success = true, data = new { message = "Dữ liệu đã được chuyển vào hệ thống kiểm duyệt " } });
        }

        [HttpGet]
        //[Authorize("Bearer")]
        [AllowAnonymous]
        [Route("kq")] // service 2
        public async Task<JsonResult> ResultThongTinQuyTrinh()
        {
            List<ThongTinQuyTrinhModel> data = await _thongtinQuyTrinhService.GetTCThongTinChungTu_Process();
            if (data == null)
            {
                return Json(new { success = false, data = new { message = "Chưa có dữ liệu cần chuyển đên hệ thống kiểm duyệt!" } });
            }

            int iResult = -1;
            try
            {
                if (data.Count > 0)
                {
                    foreach (var pThongTinQuyTrinh in data)
                    {
                        //pThongTinQuyTrinh.MA_THONGTIN = Lib.Common.Instant.getMaYC();
                        var _webRootPath = _hostingEnvironment.ContentRootPath + $"\\upload\\document\\{pThongTinQuyTrinh.ID}";
                        var o = _thongtinQuyTrinhService.UpdateThongTinQuyTrinh(pThongTinQuyTrinh, _webRootPath);
                        if (o.Status.ToString() != "Faulted")
                            iResult = 1;
                        else
                            throw o.Exception;
                    }
                }

            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Json(new { success = false, data = new { message = "Kết quả kiểm duyệt đang được tiến hành" } });

            return Json(new { success = true, data = new { message = "Kết quả kiểm duyệt đã được cập nhật " } });
        }


        // Using for KHAI System post image-data afer the service-2 call from KHAI's API
        //[Authorize("Bearer")]
        [AllowAnonymous]
        [HttpPost("uploadFile")]
        public async Task<JsonResult> ReUploadFile([FromForm] ThongTinTaiLieuModel pThongTinTaiLieu = null)
        {
            if (!ModelState.IsValid)
            {
                return Json(new { success = false, data = new { message = "Không hợp lệ" } });
            }

            if(pThongTinTaiLieu.ID_QLYC != null)
            {
                List<ThongTinBangChungModel> _ThongTinBangChungService = new List<ThongTinBangChungModel>();
                _ThongTinBangChungService = await _thongtinChungService.GetID_QLYCThongTinBangChung(int.Parse(pThongTinTaiLieu.ID_QLYC));
                pThongTinTaiLieu.IDChuTaiKhoan = int.Parse(_ThongTinBangChungService[0].MA_THONGTIN);
            }
           

            List<ThongTinTaiLieuModel> l_ThongTinTaiLieu = new List<ThongTinTaiLieuModel>();        
            l_ThongTinTaiLieu = await _ThongTinTaiLieuService.GetThongTinTaiLieu(pThongTinTaiLieu.IDChuTaiKhoan,1);
            pThongTinTaiLieu.ID = l_ThongTinTaiLieu[0].ID;
            

            pThongTinTaiLieu.FileName = pThongTinTaiLieu.MyFile.FileName;
            pThongTinTaiLieu.FileType = pThongTinTaiLieu.MyFile.ContentType;
            var uploadResult = await _uploadService.UploadDocument(pThongTinTaiLieu.FileName, pThongTinTaiLieu.FileType, pThongTinTaiLieu.MyFile, $"document/{pThongTinTaiLieu.IDChuTaiKhoan}");
            if (!uploadResult.status)
            {
                return Json(new { ErrorCode.SAVE_FAILED, uploadResult.refMsg });
            }
            else
            {
                int iResult = -1;

                pThongTinTaiLieu.TenFile = pThongTinTaiLieu.MyFile.FileName;
                pThongTinTaiLieu.DuongDan = uploadResult.filePath;
                pThongTinTaiLieu.LoaiFile = pThongTinTaiLieu.FileType;
                pThongTinTaiLieu.DienGiaiFile = pThongTinTaiLieu.UuTien == 1 ? "Tập tin chính cần trình ký" : "Tập tin đính kèm";
                if (pThongTinTaiLieu.ID == 0)
                {
                    try
                    {
                        var o = _ThongTinTaiLieuService.InsertThongTinTaiLieu(pThongTinTaiLieu);
                        if (o.Status.ToString() != "Faulted")
                            iResult = 1;
                        else
                            throw o.Exception;
                    }
                    catch (Exception ex)
                    {
                        HandlingExceptionError exceptionError = new HandlingExceptionError();
                        exceptionError.OnException(ex);
                    }

                    if (iResult == -1)
                        return Json(new { success = false, data = new { message = "Dữ liệu chưa được thêm vào hệ thống!" } });

                    return Json(new { success = true, data = new { message = "Dữ liệu đã được thêm vào hệ thống" } });
                }
                else
                {
                    try
                    {
                        var o = _ThongTinTaiLieuService.UpdateThongTinTaiLieu(pThongTinTaiLieu);
                        if (o.Status.ToString() != "Faulted")
                            iResult = 1;
                        else
                            throw o.Exception;
                    }
                    catch (Exception ex)
                    {
                        HandlingExceptionError exceptionError = new HandlingExceptionError();
                        exceptionError.OnException(ex);
                    }

                    if (iResult == -1)
                        return Json(new { success = false, data = new { message = "Dữ liệu chưa được cập nhật vào hệ thống" } });

                    return Json(new { success = true, data = new { message = "Dữ liệu đã được cập nhật vào hệ thống" } });

                }
            }
        }
        [HttpPost]
        //[Authorize("Bearer")]
        [AllowAnonymous]
        [Route("insert")]
        public string InsertThongTinQuyTrinhCate([FromBody] ThongTinQuyTrinhModel pThongTinQuyTrinh = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                var o = _thongtinQuyTrinhService.InsertThongTinQuyTrinh(pThongTinQuyTrinh);
                if (o.Status.ToString() != "Faulted")
                    iResult = 1;
                else
                    throw o.Exception;
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được thêm vào hệ thống!" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được thêm vào hệ thống" } });
        }

        #endregion
    }
}