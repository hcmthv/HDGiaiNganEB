﻿
using GiaiNganAPI.Attribute;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GiaiNganAPI.Controllers
{

    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ThongTinMauChuKyController : Controller
    {
        private readonly IThongTinMauChuKyService _thongTinMauChuKyService;
        private readonly IHostingEnvironment _hostingEnvironment;

        public ThongTinMauChuKyController(IHostingEnvironment hostingEnvironment, IThongTinMauChuKyService thongtinMauChuKyService)
        {
            _hostingEnvironment = hostingEnvironment;
            _thongTinMauChuKyService = thongtinMauChuKyService;
        }

        #region Thong tin chu tai khoan
        [HttpGet]
        [Authorize("Bearer")]
        //[AllowAnonymous]
        [Route("detail/{id}")]
        public async Task<string> GetThongTinMauChuKy(int id)
        {
            var data = await _thongTinMauChuKyService.GetThongTinMauChuKy(id);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpPost]
        [Authorize("Bearer")]
        //[AllowAnonymous]
        [Route("insert")]
        public string InsertThongTinMauChuKyCate([FromBody] ThongTinMauChuKyModel pThongTinMauChuKy = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                var o = _thongTinMauChuKyService.InsertThongTinMauChuKy(pThongTinMauChuKy);
                if (o.Status.ToString() != "Faulted")
                    iResult = 1;
                else
                    throw o.Exception;
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được thêm vào hệ thống!" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được thêm vào hệ thống" } });
        }

        [HttpPost]
        [Authorize("Bearer")]
        //[AllowAnonymous]
        [Route("update")]
        public string UpdateThongTinMauChuKyCate([FromBody] ThongTinMauChuKyModel pThongTinMauChuKy = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                var o = _thongTinMauChuKyService.UpdateThongTinMauChuKy(pThongTinMauChuKy);
                if (o.Status.ToString() != "Faulted")
                    iResult = 1;
                else
                    throw o.Exception;
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được cập nhật vào hệ thống" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được cập nhật vào hệ thống" } });
        }

        #endregion
    }
}