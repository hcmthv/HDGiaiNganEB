﻿
using GiaiNganAPI.Interfaces.Clients;
using GiaNganAPI.Services.Common.Upload;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace GiaiNganAPI.Controllers
{

    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ThongTinDungChungController : Controller
    {
        private readonly IThongTinDungChungService _ThongTinDungChungService;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IUploadService _uploadService;

        public ThongTinDungChungController(IHostingEnvironment hostingEnvironment, IThongTinDungChungService ThongTinDungChungService, IUploadService uploadService)
        {
            _hostingEnvironment = hostingEnvironment;
            _ThongTinDungChungService = ThongTinDungChungService;
            _uploadService = uploadService;
        }

        [HttpGet]
        [Authorize("Bearer")]
        //[AllowAnonymous]
        [Route("cn")]
        public async Task<string> GetThongTinChiNhanh(int? id = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinChiNhanh(id);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);

        }

        [HttpGet]
        [Authorize("Bearer")]
        //[AllowAnonymous]
        [Route("cif/{l_MaChiNhanh}")]
        public async Task<string> GetThongTinCIF(int? id = null, string l_MaChiNhanh = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinCIF(id, l_MaChiNhanh);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpGet]
        //[AllowAnonymous]
        [Authorize("Bearer")]
        [Route("tt/{l_MaChiNhanh}")]
        public async Task<string> GetThongTinTienTe(int? id = null, string l_MaChiNhanh = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinTienTe(id, l_MaChiNhanh);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpGet]
        //[AllowAnonymous]
        [Authorize("Bearer")]
        [Route("stk/{l_TienTe}/{l_MaChiNhanh}")]
        public async Task<string> GetThongTinSoTaiKhoan(int? id = null, string l_MaChiNhanh = null, string l_TienTe = null, string l_CIF = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinSoTaiKhoan(id, l_MaChiNhanh, l_TienTe, l_CIF);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpGet]
        //[AllowAnonymous]
        [Authorize("Bearer")]
        [Route("tinh")]
        public async Task<string> GetThongTinTinh(int? l_Id = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinTinh(l_Id);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpGet]
        //[AllowAnonymous]
        [Authorize("Bearer")]
        [Route("huyen/{l_PROVINCE_ID}")]
        public async Task<string> GetThongTinHuyen(int? l_PROVINCE_ID = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinHuyen(l_PROVINCE_ID);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }


        [HttpGet]
        //[AllowAnonymous]
        [Authorize("Bearer")]
        [Route("xa/{l_DISTRICT_ID}")]
        public async Task<string> GetThongTinXa(int? l_DISTRICT_ID = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinXa(l_DISTRICT_ID);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpGet]
        //[AllowAnonymous]
        [Authorize("Bearer")]
        [Route("duong/{l_PROVINCE_ID}/{l_DISTRICT_ID}")]
        public async Task<string> GetThongTinDuong(int? l_PROVINCE_ID = null, int? l_DISTRICT_ID = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinDuong(l_PROVINCE_ID, l_DISTRICT_ID);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpGet]
        [Authorize("Bearer")]
        [Route("ts/{l_nhom}")]
        public async Task<string> GetThongTinThamSo(int? id = null, string l_nhom = null)
        {
            var data = await _ThongTinDungChungService.GetThongTinThamSo(id, l_nhom);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }


    }
}