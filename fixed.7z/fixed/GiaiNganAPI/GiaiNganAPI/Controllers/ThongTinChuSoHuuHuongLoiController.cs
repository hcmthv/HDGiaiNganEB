﻿
using GiaiNganAPI.Attribute;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GiaiNganAPI.Controllers
{

    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ThongTinChuSoHuuHuongLoiController : Controller
    {
        private readonly IThongTinChuSoHuuHuongLoiService _thongTinChuSoHuuHuongLoiService;
        private readonly IHostingEnvironment _hostingEnvironment;

        public ThongTinChuSoHuuHuongLoiController(IHostingEnvironment hostingEnvironment, IThongTinChuSoHuuHuongLoiService thongtinchusohuuhuongloiService)
        {
            _hostingEnvironment = hostingEnvironment;
            _thongTinChuSoHuuHuongLoiService = thongtinchusohuuhuongloiService;
        }

        #region Thong tin chu tai khoan
        [HttpGet]
        [Authorize("Bearer")]
        [Route("detail/{id}")]
        public async Task<string> GetThongTinChuSoHuuHuongLoi(int id)
        {
            var data = await _thongTinChuSoHuuHuongLoiService.GetThongTinChuSoHuuHuongLoi(id);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpPost]
        [Authorize("Bearer")]
        [Route("insert")]
        public string InsertThongTinChuSoHuuHuongLoiCate([FromBody] ThongTinChuSoHuuHuongLoiModel pThongTinChuSoHuuHuongLoi = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                var o = _thongTinChuSoHuuHuongLoiService.InsertThongTinChuSoHuuHuongLoi(pThongTinChuSoHuuHuongLoi);
                if (o.Status.ToString() != "Faulted")
                    iResult = 1;
                else
                    throw o.Exception;
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được thêm vào hệ thống!" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được thêm vào hệ thống" } });
        }

        [HttpPost]
        [Authorize("Bearer")]
        [Route("update")]
        public string UpdateThongTinChuSoHuuHuongLoiCate([FromBody] ThongTinChuSoHuuHuongLoiModel pThongTinChuSoHuuHuongLoi = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                var o = _thongTinChuSoHuuHuongLoiService.UpdateThongTinChuSoHuuHuongLoi(pThongTinChuSoHuuHuongLoi);
                if (o.Status.ToString() != "Faulted")
                    iResult = 1;
                else
                    throw o.Exception;
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được cập nhật vào hệ thống" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được cập nhật vào hệ thống" } });
        }

        #endregion
    }
}