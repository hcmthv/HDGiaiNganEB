﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace GiaiNganAPI.Controllers
{
    // ObjectClass push file to Khai (Service 1)
    public class UploadFileModel
    {
        public string MA_THONGTIN { set; get; }
        public string ID_QLYC { set; get; }        
        public string UuTien { set; get; }
        public string DienGiaiFile { set; get; }
        public IFormFile MyImage { set; get; }
        public IFormFile other_file { set; get; }
    }

    // ObjectClass push jsondata to Khai ( service 2)
    public class JsonData
    {
        public string ID_QLYC { set; get; }
        public string ID_THONGTIN { set; get; }
    }

    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        [HttpGet("p")]
        public IActionResult GetUserData(string p)
        {
            //string a = jsonRequest.Request.Instance.httpGet("https://jsonplaceholder.typicode.com/todos/1");               
            string responseFromServer = (string)jsonRequest.Request.Instance.callAPI("https://jsonplaceholder.typicode.com/todos/1");
            var json_data = Ok(new { data = JsonConvert.DeserializeObject(responseFromServer) });
            return json_data;
        }

        [HttpPost("resultFile")]
        public ActionResult<string> Get([FromBody] JsonData _jsonData)
        {
            return  JsonConvert.SerializeObject(new { TRANG_THAI = "CANCEL", ID_QLYC = _jsonData.ID_QLYC, ID_THONGTIN = _jsonData.ID_THONGTIN });
        }

        [HttpPost("uploadfile")]
        public ActionResult<string> Get([FromForm] UploadFileModel file)
        {
            // Lưu file xuống.            
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
