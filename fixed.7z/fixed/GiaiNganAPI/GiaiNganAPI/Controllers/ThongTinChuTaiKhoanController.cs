﻿
using GiaiNganAPI.Attribute;
using GiaiNganAPI.Config;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using GiaNganAPI.Services.Common.Upload;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GiaiNganAPI.Controllers
{

    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ThongTinChuTaiKhoanController : BasicController //Controller
    {
        private readonly IThongTinChuTaiKhoanService _thongtinchutaikhoanService;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IUploadService _uploadService;

        public ThongTinChuTaiKhoanController(IHostingEnvironment hostingEnvironment, IThongTinChuTaiKhoanService thongtinchutaikhoanService, IUploadService uploadService)
        {
            _hostingEnvironment = hostingEnvironment;
            _thongtinchutaikhoanService = thongtinchutaikhoanService;
            _uploadService = uploadService;
        }

        #region Thong tin chu tai khoan
        [HttpGet]
        //[Authorize("Bearer")]
        [AllowAnonymous]
        [Route("list")]
        public async Task<string> GetTCThongTinChuTaiKhoan()
        {
            var data = await _thongtinchutaikhoanService.GetTCThongTinChuTaiKhoan();
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
                //return Json(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
            ///return Json(data);

        }

        [HttpGet]
        //[Authorize("Bearer")]
        [AllowAnonymous]
        [Route("detail/{id}")]
        public async Task<string> GetThongTinChuTaiKhoan(int id)
        {
            var data = await _thongtinchutaikhoanService.GetThongTinChuTaiKhoan(id);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
                // return Json(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
            //return Json(data);
        }

        [HttpGet]
        [Authorize("Bearer")]
        //[AllowAnonymous]
        [Route("ct/{l_SoTaiKhoan}")]
        public async Task<string> GetThongTinChuSoTaiKhoan(int? l_Id = null, string l_SoTaiKhoan = null)
        {
            var data = await _thongtinchutaikhoanService.GetThongTinChuSoTaiKhoan(l_Id, l_SoTaiKhoan);
            if (data == null)
            {
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Không tìm thấy dữ liệu" } });
            }
            return Lib.Common.ConvertToBase64Encode(data);
        }

        [HttpPost]
        [Authorize("Bearer")]
        //[AllowAnonymous]
        [Route("insert")]
        public async Task<string> InsertThongTinChuTaiKhoan([FromBody] ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                pThongTinChuTaiKhoan.Ma_ThongTin = Lib.Common.Instant.getMaYC();
                iResult = await _thongtinchutaikhoanService.InsertThongTinChuTaiKhoan(pThongTinChuTaiKhoan);               

                /* if (o.Status.ToString() != "Faulted")
                     iResult = 1;
                 else
                     throw o.Exception;*/
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);

                var plainTextBytes = JsonConvert.SerializeObject(pThongTinChuTaiKhoan);
                exceptionError.logFile("ThongTinChuTaiKhoanModel", "Insert", plainTextBytes);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được thêm vào hệ thống!" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được thêm vào hệ thống" }, idThongTin = iResult });
        }

        [HttpPost]
        [Authorize("Bearer")]
        //[AllowAnonymous]
        [Route("update")]
        public string UpdateThongTinChuTaiKhoan([FromBody] ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null)
        {
            if (!ModelState.IsValid)
            {
                var modelErrMsg = "";
                var allErrors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var modelError in allErrors)
                {
                    modelErrMsg += modelError.ErrorMessage;
                }

                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = modelErrMsg } });
            }

            int iResult = -1;
            try
            {
                var o = _thongtinchutaikhoanService.UpdateThongTinChuTaiKhoan(pThongTinChuTaiKhoan);
                if (o.Status.ToString() != "Faulted")
                    iResult = 1;
                else
                    throw o.Exception;
            }
            catch (Exception ex)
            {
                HandlingExceptionError exceptionError = new HandlingExceptionError();
                exceptionError.OnException(ex);

                var plainTextBytes = JsonConvert.SerializeObject(pThongTinChuTaiKhoan);
                exceptionError.logFile("ThongTinChuTaiKhoanModel", "Update", plainTextBytes);
            }

            if (iResult == -1)
                return Lib.Common.ConvertToBase64Encode(new { success = false, data = new { message = "Dữ liệu chưa được cập nhật vào hệ thống" } });

            return Lib.Common.ConvertToBase64Encode(new { success = true, data = new { message = "Dữ liệu đã được cập nhật vào hệ thống" } });
        }

        #endregion


    }
}