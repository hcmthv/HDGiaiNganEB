﻿using Dapper;
using GiaiNganAPI.DAL.Core;
using GiaiNganAPI.Entities.Clients;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace GiaiNganAPI.DAL.Dapper
{
    public class ThongTinDungChungManager : dapperDAL
    {
        public static ThongTinDungChungManager Instance { get; } = new ThongTinDungChungManager();

        public List<ThongTinChiNhanhModel> GetThongTinChiNhanh(int? l_Id = null)
        {
            List<ThongTinChiNhanhModel> ThongTinChuTaiKhoanList = new List<ThongTinChiNhanhModel>();
            try
            {
                var lSql = $"select * from TBL_ChiNhanh where 1 = 1";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinChiNhanhModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }


        public List<ThongTinSoTaiKhoanModel> GetThongTinCIF(int? l_Id = null, string l_MaChiNhanh = null)
        {
            List<ThongTinSoTaiKhoanModel> ThongTinChuTaiKhoanList = new List<ThongTinSoTaiKhoanModel>();
            try
            {
                var lSql = $"select * from TBL_SoTaiKhoan where ChiNhanh like (case when isnull(N'{l_MaChiNhanh}','') != '' then N'{l_MaChiNhanh}' else '%' end) and ID_ChuTaiKhoan is null";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinSoTaiKhoanModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinSoTaiKhoanModel> GetThongTinTienTe(int? l_Id = null, string l_MaChiNhanh = null)
        {
            List<ThongTinSoTaiKhoanModel> ThongTinChuTaiKhoanList = new List<ThongTinSoTaiKhoanModel>();
            try
            {
                var lSql = $"select distinct loaitien from TBL_SoTaiKhoan where ChiNhanh like (case when isnull(N'{l_MaChiNhanh}','') != '' then N'{l_MaChiNhanh}' else '%' end)";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinSoTaiKhoanModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinSoTaiKhoanModel> GetThongTinSoTaiKhoan(int? l_Id = null, string l_MaChiNhanh = null, string l_TienTe = null, string l_CIF = null)
        {
            List<ThongTinSoTaiKhoanModel> ThongTinChuTaiKhoanList = new List<ThongTinSoTaiKhoanModel>();
            try
            {
                var lSql = $"select * from TBL_SoTaiKhoan where ChiNhanh like (case when isnull(N'{l_MaChiNhanh}','') != '' then N'{l_MaChiNhanh}' else '%' end) and ID_ChuTaiKhoan is null ";
                lSql += $" and loaitien = N'{l_TienTe}' and cif like (case when isnull(N'{l_CIF}','') != '' then N'{l_CIF}' else '%' end) ";
                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinSoTaiKhoanModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinThamSoModel> GetThongTinThamSo(int? l_Id = null, string l_nhom = null)
        {
            List<ThongTinThamSoModel> ThongTinChuTaiKhoanList = new List<ThongTinThamSoModel>();
            try
            {
                var lSql = $"select * from TBL_ThamSo where nhom like (case when isnull(N'{l_nhom}','') != '' then N'{l_nhom}' else '%' end)";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinThamSoModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinTinhModel> GetThongTinTinh(int? l_Id = null)
        {
            List<ThongTinTinhModel> ThongTinChuTaiKhoanList = new List<ThongTinTinhModel>();
            try
            {
                var lSql = $"select * from TBL_Tinh";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinTinhModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinHuyenModel> GetThongTinHuyen(int? l_PROVINCE_ID = null)
        {
            List<ThongTinHuyenModel> ThongTinChuTaiKhoanList = new List<ThongTinHuyenModel>();
            try
            {
                var lSql = $"select * from TBL_Huyen where PROVINCE_ID = {l_PROVINCE_ID}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinHuyenModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinXaModel> GetThongTinXa(int? l_DISTRICT_ID = null)
        {
            List<ThongTinXaModel> ThongTinChuTaiKhoanList = new List<ThongTinXaModel>();
            try
            {
                var lSql = $"select * from TBL_Xa where DISTRICT_ID = {l_DISTRICT_ID}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinXaModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinDuongModel> GetThongTinDuong(int? l_PROVINCE_ID = null, int? l_DISTRICT_ID = null)
        {
            List<ThongTinDuongModel> ThongTinChuTaiKhoanList = new List<ThongTinDuongModel>();
            try
            {
                var lSql = $"select * from TBL_Duong where PROVINCE_ID = {l_PROVINCE_ID} and DISTRICT_ID ={l_DISTRICT_ID}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinDuongModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }
    }
}

