﻿using Dapper;
using GiaiNganAPI.DAL.Core;
using GiaiNganAPI.Entities.Clients;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace GiaiNganAPI.DAL.Dapper
{
    public class ThongTinTaiLieuManager : dapperDAL
    {
        public static ThongTinTaiLieuManager Instance { get; } = new ThongTinTaiLieuManager();

        public List<ThongTinTaiLieuModel> GetThongTinTaiLieu(int? l_Id = null, int? l_UuTien = null)
        {
            List<ThongTinTaiLieuModel> ThongTinChuTaiKhoanList = new List<ThongTinTaiLieuModel>();
            try
            {
                var subQuery = l_UuTien != null ? $" and UuTien = {l_UuTien}" : " and 1 = 1";
                var lSql = $"select * from vw_TBL_ThongTinTaiLieu where IDChuTaiKhoan ={l_Id} {subQuery}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinTaiLieuModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public int ProcessSql(string status = null, ThongTinTaiLieuModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            int outValue = -1;
            var conn = openConnection();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("p_status", status);
                if (pThongTinChuTaiKhoan != null)
                {
                    param.Add("p_ID", pThongTinChuTaiKhoan.ID);
                    param.Add("p_IDChuTaiKhoan", pThongTinChuTaiKhoan.IDChuTaiKhoan);
                    param.Add("p_TenFile", pThongTinChuTaiKhoan.TenFile);
                    param.Add("p_DuongDan", pThongTinChuTaiKhoan.DuongDan);
                    param.Add("p_TinhTrang", pThongTinChuTaiKhoan.TinhTrang);
                    param.Add("p_UuTien", pThongTinChuTaiKhoan.UuTien);
                    param.Add("p_DienGiaiFile", pThongTinChuTaiKhoan.DienGiaiFile);

                    if (pThongTinChuTaiKhoan.NgayTao == DateTime.MinValue || pThongTinChuTaiKhoan.NgaySua == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NgayTao = DateTime.Now;
                        pThongTinChuTaiKhoan.NgaySua = DateTime.Now;
                    }

                    param.Add("p_NgayTao", pThongTinChuTaiKhoan.NgayTao);
                    param.Add("p_Ngaysua", pThongTinChuTaiKhoan.NgaySua);
                    //param.Add("p_NguoiDungDangNhap", pThongTinChuTaiKhoan.NguoiDungDangNhap);
                    param.Add("p_NguoiDungDangNhap", "SysGiaiNganEB");
                    param.Add("p_LoaiFile", pThongTinChuTaiKhoan.LoaiFile);
                    
                }

                param.Add("@p_outValue", dbType: DbType.Int32, direction: ParameterDirection.Output);

                conn.Open();
                iResult = conn.Execute("sp_TBL_File", param, null, null, commandType: CommandType.StoredProcedure);


                if (status == "INSERT")
                {
                    outValue = param.Get<Int32>("@p_outValue");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            iResult = outValue;
            return iResult;
        }

    }
}
