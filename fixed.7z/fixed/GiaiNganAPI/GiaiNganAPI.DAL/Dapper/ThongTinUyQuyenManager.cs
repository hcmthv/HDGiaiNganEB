﻿using Dapper;
using GiaiNganAPI.DAL.Core;
using GiaiNganAPI.Entities.Clients;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace GiaiNganAPI.DAL.Dapper
{
    public class ThongTinUyQuyenManager : dapperDAL
    {
        public static ThongTinUyQuyenManager Instance { get; } = new ThongTinUyQuyenManager();

        public List<ThongTinUyQuyenModel> GetThongTinUyQuyen(int? l_Id = null)
        {
            List<ThongTinUyQuyenModel> ThongTinChuTaiKhoanList = new List<ThongTinUyQuyenModel>();
            try
            {
                var lSql = $"select * from TBL_ThongTinUyQuyen where ID_ChuTaiKhoan ={l_Id}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinUyQuyenModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public int ProcessSql(string status = null, ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            int outValue = -1;
            var conn = openConnection();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("p_status", status);
                if (pThongTinChuTaiKhoan != null)
                {
                    param.Add("p_ID", pThongTinChuTaiKhoan.ID);
                    param.Add("p_ID_ChuTaiKhoan", pThongTinChuTaiKhoan.ID_ChuTaiKhoan);
                    param.Add("p_HoTen", pThongTinChuTaiKhoan.HoTen);
                    param.Add("p_TenTiengAnh", pThongTinChuTaiKhoan.TenTiengAnh);
                    param.Add("p_SoCMND", pThongTinChuTaiKhoan.SoCMND);
                    param.Add("p_GiayPhepHoatDong_So", pThongTinChuTaiKhoan.GiayPhepHoatDong_So);
                    param.Add("p_DiaChiTT", pThongTinChuTaiKhoan.DiaChiTT);
                    param.Add("p_LoaiTaiSan", pThongTinChuTaiKhoan.LoaiTaiSan);
                    param.Add("p_GiaTri", pThongTinChuTaiKhoan.GiaTri);
                    param.Add("p_NoiDung", pThongTinChuTaiKhoan.NoiDung);
                    param.Add("p_NgayUyQuyen", pThongTinChuTaiKhoan.NgayUyQuyen);
                    param.Add("p_SoDinhDanhUyQuyen", pThongTinChuTaiKhoan.SoDinhDanhUyQuyen);
                    param.Add("p_TenNguoiHuongLoi", pThongTinChuTaiKhoan.TenNguoiHuongLoi);

                    if (pThongTinChuTaiKhoan.NgayTao == DateTime.MinValue || pThongTinChuTaiKhoan.NgaySua == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NgayTao = DateTime.Now;
                        pThongTinChuTaiKhoan.NgaySua = DateTime.Now;
                    }

                    param.Add("p_NgayTao", pThongTinChuTaiKhoan.NgayTao);
                    param.Add("p_Ngaysua", pThongTinChuTaiKhoan.NgaySua);
                    //param.Add("p_NguoiDungDangNhap", pThongTinChuTaiKhoan.NguoiDungDangNhap);
                    param.Add("p_NguoiDungDangNhap", "SysGiaiNganEB");
                }

                param.Add("@p_outValue", dbType: DbType.Int32, direction: ParameterDirection.Output);

                conn.Open();
                iResult = conn.Execute("sp_TBL_ThongTinUyQuyen", param, null, null, commandType: CommandType.StoredProcedure);


                if (status == "INSERT")
                {
                    outValue = param.Get<Int32>("@p_outValue");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            iResult = outValue;
            return iResult;
        }

    }
}
