﻿using Dapper;
using GiaiNganAPI.DAL.Core;
using GiaiNganAPI.Entities.Clients;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace GiaiNganAPI.DAL.Dapper
{
    public class ThongTinChuSoHuuHuongLoiManager : dapperDAL
    {
        public static ThongTinChuSoHuuHuongLoiManager Instance { get; } = new ThongTinChuSoHuuHuongLoiManager();

        public List<ThongTinChuSoHuuHuongLoiModel> GetThongTinChuSoHuuHuongLoi(int? l_Id = null)
        {
            List<ThongTinChuSoHuuHuongLoiModel> ThongTinChuTaiKhoanList = new List<ThongTinChuSoHuuHuongLoiModel>();
            try
            {
                var lSql = $"select * from TBL_ThongTinChuSoHuuHuongLoi where ID_ChuTaiKhoan ={l_Id}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinChuSoHuuHuongLoiModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public int ProcessSql(string status = null, ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            int outValue = -1;
            var conn = openConnection();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("p_status", status);
                if (pThongTinChuTaiKhoan != null)
                {
                    param.Add("p_ID", pThongTinChuTaiKhoan.ID);
                    param.Add("p_ID_ChuTaiKhoan", pThongTinChuTaiKhoan.ID_ChuTaiKhoan);
                    param.Add("p_LoaiChuSoHuu", pThongTinChuTaiKhoan.LoaiChuSoHuu);
                    param.Add("p_HoTen", pThongTinChuTaiKhoan.HoTen);
                    param.Add("p_CMND", pThongTinChuTaiKhoan.CMND);
                    param.Add("p_NgayCap", pThongTinChuTaiKhoan.NgayCap);
                    param.Add("p_NoiCap", pThongTinChuTaiKhoan.NoiCap);
                    param.Add("p_NgaySinh", pThongTinChuTaiKhoan.NgaySinh);
                    param.Add("p_QuocTich", pThongTinChuTaiKhoan.QuocTich);
                    param.Add("p_DiaChiThuongTru", pThongTinChuTaiKhoan.DiaChiThuongTru);

                    param.Add("p_DiaChiThuongTru_Tinh", pThongTinChuTaiKhoan.DiaChiThuongTru_Tinh);
                    param.Add("p_DiaChiThuongTru_Huyen", pThongTinChuTaiKhoan.DiaChiThuongTru_Huyen);
                    param.Add("p_DiaChiThuongTru_Xa", pThongTinChuTaiKhoan.DiaChiThuongTru_Xa);
                    param.Add("p_DiaChiThuongTru_Duong", pThongTinChuTaiKhoan.DiaChiThuongTru_Duong);
                    param.Add("p_DiaChiLienLac", pThongTinChuTaiKhoan.DiaChiLienLac);
                    param.Add("p_DiaChiLienLac_Tinh", pThongTinChuTaiKhoan.DiaChiLienLac_Tinh);
                    param.Add("p_DiaChiLienLac_Huyen", pThongTinChuTaiKhoan.DiaChiLienLac_Huyen);
                    param.Add("p_DiaChiLienLac_Xa", pThongTinChuTaiKhoan.DiaChiLienLac_Xa);
                    param.Add("p_DiaChiLienLac_Duong", pThongTinChuTaiKhoan.DiaChiLienLac_Duong);

                    param.Add("p_DiDong", pThongTinChuTaiKhoan.DiDong);
                    param.Add("p_NgheNghiep", pThongTinChuTaiKhoan.NgheNghiep);
                    param.Add("p_ChucVu", pThongTinChuTaiKhoan.ChucVu);
                    param.Add("p_CongTy", pThongTinChuTaiKhoan.CongTy);
                    param.Add("p_TenDoanhNghiep", pThongTinChuTaiKhoan.TenDoanhNghiep);
                    param.Add("p_DiaChiTruSo", pThongTinChuTaiKhoan.DiaChiTruSo);
                    param.Add("p_DienThoaiCoDinh", pThongTinChuTaiKhoan.DienThoaiCoDinh);
                    param.Add("p_Fax", pThongTinChuTaiKhoan.Fax);

                    if (pThongTinChuTaiKhoan.NgayTao == DateTime.MinValue || pThongTinChuTaiKhoan.NgaySua == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NgayTao = DateTime.Now;
                        pThongTinChuTaiKhoan.NgaySua = DateTime.Now;
                    }

                    param.Add("p_TrucTiepGianTiep", pThongTinChuTaiKhoan.TrucTiepGianTiep);
                    param.Add("p_TenToChucSoHuu", pThongTinChuTaiKhoan.TenToChucSoHuu);
                    param.Add("p_TyLeSoHuu", pThongTinChuTaiKhoan.TyLeSoHuu);
                    param.Add("p_SoGPHD", pThongTinChuTaiKhoan.SoGPHD);
                    param.Add("p_QuocGiaDatTruSoChinh", pThongTinChuTaiKhoan.QuocGiaDatTruSoChinh);

                    param.Add("p_NgayTao", pThongTinChuTaiKhoan.NgayTao);
                    param.Add("p_Ngaysua", pThongTinChuTaiKhoan.NgaySua);
                    //param.Add("p_NguoiDungDangNhap", pThongTinChuTaiKhoan.NguoiDungDangNhap);
                    param.Add("p_NguoiDungDangNhap", "SysGiaiNganEB");
                }

                param.Add("@p_outValue", dbType: DbType.Int32, direction: ParameterDirection.Output);

                conn.Open();
                iResult = conn.Execute("sp_TBL_ThongTinChuSoHuuHuongLoi", param, null, null, commandType: CommandType.StoredProcedure);


                if (status == "INSERT")
                {
                    outValue = param.Get<Int32>("@p_outValue");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            iResult = outValue;
            return iResult;
        }

    }
}
