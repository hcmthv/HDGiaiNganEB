﻿using Dapper;
using GiaiNganAPI.DAL.Core;
using GiaiNganAPI.Entities.Clients;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace GiaiNganAPI.DAL.Dapper
{
    public class ThongTinChuTaiKhoanManager : dapperDAL
    {
        public static ThongTinChuTaiKhoanManager Instance { get; } = new ThongTinChuTaiKhoanManager();

        public List<ThongTinChuTaiKhoanModel> GetTCThongTinChuTaiKhoan()
        {
            List<ThongTinChuTaiKhoanModel> ThongTinChuTaiKhoanList = new List<ThongTinChuTaiKhoanModel>();
            try
            {
                var lSql = "select * from TBL_ThongTinChuTaiKhoan";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinChuTaiKhoanModel>(lSql).ToList();
                }

                if (ThongTinChuTaiKhoanList.Count > 0)
                {
                    List<ThongTinChuSoHuuHuongLoiModel> ThongTinChuSoHuuHuongLoiList = new List<ThongTinChuSoHuuHuongLoiModel>();
                    int iCount = -1;
                    foreach (var _thongtinchutaikhoan in ThongTinChuTaiKhoanList)
                    {
                        lSql = $"select * from TBL_ThongTinChuSoHuuHuongLoi where ID_ChuTaiKhoan = {_thongtinchutaikhoan.ID} ";
                        using (var conn = openConnection())
                        {
                            ThongTinChuSoHuuHuongLoiList = conn.Query<ThongTinChuSoHuuHuongLoiModel>(lSql).ToList();
                        }

                        iCount = iCount + 1;
                        ThongTinChuTaiKhoanList[iCount].ThongTinChuSoHuuHuongLoi.AddRange(ThongTinChuSoHuuHuongLoiList);
                    }


                    List<ThongTinMauChuKyModel> ThongTinMauChuKyList = new List<ThongTinMauChuKyModel>();
                    iCount = -1;
                    foreach (var _thongtinchutaikhoan in ThongTinChuTaiKhoanList)
                    {
                        lSql = $"select * from TBL_MauChuKy where IDChuTaiKhoan = {_thongtinchutaikhoan.ID} ";
                        using (var conn = openConnection())
                        {
                            ThongTinMauChuKyList = conn.Query<ThongTinMauChuKyModel>(lSql).ToList();
                        }

                        iCount = iCount + 1;
                        ThongTinChuTaiKhoanList[iCount].ThongTinMauChuKy.AddRange(ThongTinMauChuKyList);
                    }

                    List<ThongTinUyQuyenModel> ThongTinUyQuyenList = new List<ThongTinUyQuyenModel>();
                    iCount = -1;
                    foreach (var _thongtinchutaikhoan in ThongTinChuTaiKhoanList)
                    {
                        lSql = $"select * from TBL_ThongTinUyQuyen  where ID_ChuTaiKhoan = {_thongtinchutaikhoan.ID} ";
                        using (var conn = openConnection())
                        {
                            ThongTinUyQuyenList = conn.Query<ThongTinUyQuyenModel>(lSql).ToList();
                        }

                        iCount = iCount + 1;

                        if (ThongTinUyQuyenList.Count > 0)
                            ThongTinChuTaiKhoanList[iCount].ThongTinUyQuyen = ThongTinUyQuyenList[0];
                    }

                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinChuTaiKhoanModel> GetThongTinChuTaiKhoan(int? l_Id = null)
        {
            List<ThongTinChuTaiKhoanModel> ThongTinChuTaiKhoanList = new List<ThongTinChuTaiKhoanModel>();
            try
            {
                var lSql = $"select * from TBL_ThongTinChuTaiKhoan where ID = {l_Id} ";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinChuTaiKhoanModel>(lSql).ToList();
                }

                if (ThongTinChuTaiKhoanList.Count > 0)
                {
                    List<ThongTinChuSoHuuHuongLoiModel> ThongTinChuSoHuuHuongLoiList = new List<ThongTinChuSoHuuHuongLoiModel>();
                    lSql = $"select * from TBL_ThongTinChuSoHuuHuongLoi where ID_ChuTaiKhoan = {ThongTinChuTaiKhoanList[0].ID} ";
                    using (var conn = openConnection())
                    {
                        ThongTinChuSoHuuHuongLoiList = conn.Query<ThongTinChuSoHuuHuongLoiModel>(lSql).ToList();
                    }

                    ThongTinChuTaiKhoanList[0].ThongTinChuSoHuuHuongLoi.AddRange(ThongTinChuSoHuuHuongLoiList);

                    // add more signature 
                    List<ThongTinMauChuKyModel> ThongTinMauChuKyList = new List<ThongTinMauChuKyModel>();
                    lSql = $"select * from TBL_MauChuKy where IDChuTaiKhoan = {ThongTinChuTaiKhoanList[0].ID} ";
                    using (var conn = openConnection())
                    {
                        ThongTinMauChuKyList = conn.Query<ThongTinMauChuKyModel>(lSql).ToList();
                    }

                    ThongTinChuTaiKhoanList[0].ThongTinMauChuKy.AddRange(ThongTinMauChuKyList);


                    List<ThongTinUyQuyenModel> ThongTinUyQuyenList = new List<ThongTinUyQuyenModel>();
                    lSql = $"select * from TBL_ThongTinUyQuyen where ID_ChuTaiKhoan = {ThongTinChuTaiKhoanList[0].ID} ";
                    using (var conn = openConnection())
                    {
                        ThongTinUyQuyenList = conn.Query<ThongTinUyQuyenModel>(lSql).ToList();
                    }

                    if (ThongTinUyQuyenList.Count > 0)
                        ThongTinChuTaiKhoanList[0].ThongTinUyQuyen = ThongTinUyQuyenList[0];


                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinChuTaiKhoanModel> GetThongTinChuSoTaiKhoan(int? l_Id = null, string l_SoTaiKhoan = null)
        {
            List<ThongTinChuTaiKhoanModel> ThongTinChuTaiKhoanList = new List<ThongTinChuTaiKhoanModel>();
            try
            {
                var lSql = $"select * from vw_getThongtinChuTaiKhoan where stk like (case when isnull(N'{l_SoTaiKhoan}','') != '' then N'{l_SoTaiKhoan}' else '%' end) ";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinChuTaiKhoanModel>(lSql).ToList();
                }

                if (ThongTinChuTaiKhoanList.Count > 0)
                {
                    List<ThongTinChuSoHuuHuongLoiModel> ThongTinChuSoHuuHuongLoiList = new List<ThongTinChuSoHuuHuongLoiModel>();
                    lSql = $"select * from TBL_ThongTinChuSoHuuHuongLoi where ID_ChuTaiKhoan = {ThongTinChuTaiKhoanList[0].ID} ";
                    using (var conn = openConnection())
                    {
                        ThongTinChuSoHuuHuongLoiList = conn.Query<ThongTinChuSoHuuHuongLoiModel>(lSql).ToList();
                    }

                    ThongTinChuTaiKhoanList[0].ThongTinChuSoHuuHuongLoi.AddRange(ThongTinChuSoHuuHuongLoiList);

                    // add more signature 
                    List<ThongTinMauChuKyModel> ThongTinMauChuKyList = new List<ThongTinMauChuKyModel>();
                    lSql = $"select * from TBL_MauChuKy where IDChuTaiKhoan = {ThongTinChuTaiKhoanList[0].ID} ";
                    using (var conn = openConnection())
                    {
                        ThongTinMauChuKyList = conn.Query<ThongTinMauChuKyModel>(lSql).ToList();
                    }

                    ThongTinChuTaiKhoanList[0].ThongTinMauChuKy.AddRange(ThongTinMauChuKyList);


                    List<ThongTinUyQuyenModel> ThongTinUyQuyenList = new List<ThongTinUyQuyenModel>();
                    lSql = $"select * from TBL_ThongTinUyQuyen where ID_ChuTaiKhoan = {ThongTinChuTaiKhoanList[0].ID} ";
                    using (var conn = openConnection())
                    {
                        ThongTinUyQuyenList = conn.Query<ThongTinUyQuyenModel>(lSql).ToList();
                    }

                    if (ThongTinUyQuyenList.Count > 0)
                        ThongTinChuTaiKhoanList[0].ThongTinUyQuyen = ThongTinUyQuyenList[0];

                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public int ProcessSql(string status = null, ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            var conn = openConnection();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("p_status", status);
                if (pThongTinChuTaiKhoan != null)
                {
                    param.Add("p_ID", pThongTinChuTaiKhoan.ID);
                    param.Add("p_CTK_Ten", pThongTinChuTaiKhoan.CTK_Ten);
                    param.Add("p_CTK_TenNuocNgoai", pThongTinChuTaiKhoan.CTK_TenNuocNgoai);
                    param.Add("p_CTK_TenVietTat", pThongTinChuTaiKhoan.CTK_TenVietTat);
                    param.Add("p_CTK_DiaChiTruSo", pThongTinChuTaiKhoan.CTK_DiaChiTruSo);


                    param.Add("p_CTK_DiaChiTruSo_Tinh", pThongTinChuTaiKhoan.CTK_DiaChiTruSo_Tinh);
                    param.Add("p_CTK_DiaChiTruSo_Huyen", pThongTinChuTaiKhoan.CTK_DiaChiTruSo_Huyen);
                    param.Add("p_CTK_DiaChiTruSo_Xa", pThongTinChuTaiKhoan.CTK_DiaChiTruSo_Xa);
                    param.Add("p_CTK_DiaChiTruSo_Duong", pThongTinChuTaiKhoan.CTK_DiaChiTruSo_Duong);
                    param.Add("p_CTK_DiaChiGiaoDich", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich);
                    param.Add("p_CTK_DiaChiGiaoDich_Tinh", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich_Tinh);
                    param.Add("p_CTK_DiaChiGiaoDich_Huyen", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich_Huyen);
                    param.Add("p_CTK_DiaChiGiaoDich_Xa", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich_Xa);
                    param.Add("p_CTK_DiaChiGiaoDich_Duong", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich_Duong);

                    param.Add("p_CTK_SDTCoDinh", pThongTinChuTaiKhoan.CTK_SDTCoDinh);
                    param.Add("p_CTK_Fax", pThongTinChuTaiKhoan.CTK_Fax);
                    param.Add("p_CTK_Email", pThongTinChuTaiKhoan.CTK_Email);
                    param.Add("p_CTK_MaSoThue", pThongTinChuTaiKhoan.CTK_MaSoThue);
                    param.Add("p_CTK_CuTru", pThongTinChuTaiKhoan.CTK_CuTru);
                    param.Add("p_CTK_GiayPhepHoatDong_So", pThongTinChuTaiKhoan.CTK_GiayPhepHoatDong_So);
                    param.Add("p_CTK_GiayPhepHoatDong_NgayCap", pThongTinChuTaiKhoan.CTK_GiayPhepHoatDong_NgayCap);
                    param.Add("p_CTK_GiayPhepHoatDong_NoiCap", pThongTinChuTaiKhoan.CTK_GiayPhepHoatDong_NoiCap);
                    param.Add("p_CTK_LinhVucKinhDoanh", pThongTinChuTaiKhoan.CTK_LinhVucKinhDoanh);
                    param.Add("p_CTK_DoanhThuGanNhat", pThongTinChuTaiKhoan.CTK_DoanhThuGanNhat);
                    param.Add("p_CTK_LoaiHinhToChuc", pThongTinChuTaiKhoan.CTK_LoaiHinhToChuc);
                    param.Add("p_TCTT_Ten", pThongTinChuTaiKhoan.TCTT_Ten);
                    param.Add("p_TCTT_TenNuocNgoai", pThongTinChuTaiKhoan.TCTT_TenNuocNgoai);
                    param.Add("p_TCTT_TenVietTat", pThongTinChuTaiKhoan.TCTT_TenVietTat);
                    param.Add("p_TCTT_DiaChiTruSo", pThongTinChuTaiKhoan.TCTT_DiaChiTruSo);
                    param.Add("p_TCTT_DiaChiGiaoDich", pThongTinChuTaiKhoan.TCTT_DiaChiGiaoDich);
                    param.Add("p_TCTT_SDTCoDinh", pThongTinChuTaiKhoan.TCTT_SDTCoDinh);
                    param.Add("p_TCTT_Fax", pThongTinChuTaiKhoan.TCTT_Fax);
                    param.Add("p_TCTT_Email", pThongTinChuTaiKhoan.TCTT_Email);
                    param.Add("p_TCTT_MaSoThue", pThongTinChuTaiKhoan.TCTT_MaSoThue);
                    param.Add("p_TCTT_CuTru", pThongTinChuTaiKhoan.TCTT_CuTru);
                    param.Add("p_TCTT_GiayPhepHoatDong_So", pThongTinChuTaiKhoan.TCTT_GiayPhepHoatDong_So);
                    param.Add("p_CTK_GiayPhepHoatDong_Loai", pThongTinChuTaiKhoan.CTK_GiayPhepHoatDong_Loai);
                    param.Add("p_TCTT_GiayPhepHoatDong_NgayCap", pThongTinChuTaiKhoan.TCTT_GiayPhepHoatDong_NgayCap);
                    param.Add("p_TCTT_GiayPhepHoatDong_NoiCap", pThongTinChuTaiKhoan.TCTT_GiayPhepHoatDong_NoiCap);
                    param.Add("p_TCTT_DoanhThuGanNhat", pThongTinChuTaiKhoan.TCTT_DoanhThuGanNhat);
                    param.Add("p_TCTT_NguoiDaiDien_Ten", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_Ten);
                    param.Add("p_TCTT_NguoiDaiDien_CMND", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_CMND);
                    param.Add("p_TCTT_NguoiDaiDien_NgayCap", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_NgayCap);
                    param.Add("p_TCTT_NguoiDaiDien_NoiCap", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_NoiCap);
                    param.Add("p_TCTT_NguoiDaiDien_NgaySinh", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_NgaySinh);
                    param.Add("p_TCTT_NguoiDaiDien_SDT", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_SDT);
                    param.Add("p_TCTT_VanBanUyQuen", pThongTinChuTaiKhoan.TCTT_VanBanUyQuen);
                    param.Add("p_FATCA_ToChucDuocThanhLap", pThongTinChuTaiKhoan.FATCA_ToChucDuocThanhLap);
                    param.Add("p_FATCA_ToChucCoNguoiKiemSoat", pThongTinChuTaiKhoan.FATCA_ToChucCoNguoiKiemSoat);
                    param.Add("p_FATCA_TCTT_MaGIIN", pThongTinChuTaiKhoan.FATCA_TCTT_MaGIIN);
                    param.Add("p_FATCA_TCTT_ChuaDangKy", pThongTinChuTaiKhoan.FATCA_TCTT_ChuaDangKy);
                    param.Add("p_FATCA_KhongPhai3DoiTuongTren", pThongTinChuTaiKhoan.FATCA_KhongPhai3DoiTuongTren);
                    param.Add("p_TKTienGuiThanhToan", pThongTinChuTaiKhoan.TKTienGuiThanhToan);
                    param.Add("p_TKTienGuiLuyTien", pThongTinChuTaiKhoan.TKTienGuiLuyTien);
                    param.Add("p_TKTienGuiLinhHoat", pThongTinChuTaiKhoan.TKTienGuiLinhHoat);
                    param.Add("p_TKTienGuiTichLuyTuDong", pThongTinChuTaiKhoan.TKTienGuiTichLuyTuDong);
                    param.Add("p_TKTienGuiToiUuThanhKhoan", pThongTinChuTaiKhoan.TKTienGuiToiUuThanhKhoan);
                    param.Add("p_TKTienGuiKhac", pThongTinChuTaiKhoan.TKTienGuiKhac);
                    param.Add("p_SoPhuTK_TanSuatNhan", pThongTinChuTaiKhoan.SoPhuTK_TanSuatNhan);
                    param.Add("p_SoPhuTK_PhuongTienGui", pThongTinChuTaiKhoan.SoPhuTK_PhuongTienGui);
                    param.Add("p_DK_Ibanking", pThongTinChuTaiKhoan.DK_Ibanking);
                    param.Add("p_DK_SMSBanking", pThongTinChuTaiKhoan.DK_SMSBanking);
                    param.Add("p_TrangThai", pThongTinChuTaiKhoan.TrangThai);

                    if (pThongTinChuTaiKhoan.NgayTao == DateTime.MinValue || pThongTinChuTaiKhoan.NgaySua == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NgayTao = DateTime.Now;
                        pThongTinChuTaiKhoan.NgaySua = DateTime.Now;
                    }

                    param.Add("p_NgayTao", pThongTinChuTaiKhoan.NgayTao);
                    param.Add("p_Ngaysua", pThongTinChuTaiKhoan.NgaySua);
                    //param.Add("p_NguoiDungDangNhap", pThongTinChuTaiKhoan.NguoiDungDangNhap);
                    param.Add("p_NguoiDungDangNhap", "SysGiaiNganEB");
                    param.Add("p_ChiNhanh", pThongTinChuTaiKhoan.ChiNhanh);

                    param.Add("p_CIF", pThongTinChuTaiKhoan.CIF);
                    param.Add("p_STK", pThongTinChuTaiKhoan.STK);
                    param.Add("p_Ma_ThongTin", pThongTinChuTaiKhoan.Ma_ThongTin);
                   
                }

                param.Add("@p_outValue", dbType: DbType.Int32, direction: ParameterDirection.Output);

                conn.Open();
                iResult = conn.Execute("sp_TBL_ThongTinChuTaiKhoan", param, null, null, commandType: CommandType.StoredProcedure);


                if (status == "INSERT")
                {
                    iResult = param.Get<Int32>("@p_outValue");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return iResult;
        }

    }
}
