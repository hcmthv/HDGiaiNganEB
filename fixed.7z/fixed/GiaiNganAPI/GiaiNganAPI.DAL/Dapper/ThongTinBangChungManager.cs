﻿using Dapper;
using GiaiNganAPI.DAL.Core;
using GiaiNganAPI.Entities.Clients;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace GiaiNganAPI.DAL.Dapper
{
    public class ThongTinBangChungManager : dapperDAL
    {
        public static ThongTinBangChungManager Instance { get; } = new ThongTinBangChungManager();

        public List<ThongTinBangChungModel> GetID_QLYCThongTinBangChung(int ? l_ID_QLYC = null)
        {
            List<ThongTinBangChungModel> ThongTinChuTaiKhoanList = new List<ThongTinBangChungModel>();
            try
            {
                var lSql = $"select * from TBL_ThongTin_Chung where ID_QLYC = {l_ID_QLYC}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinBangChungModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }
        public List<ThongTinBangChungModel> GetThongTinBangChung(int? l_Id = null)
        {
            List<ThongTinBangChungModel> ThongTinChuTaiKhoanList = new List<ThongTinBangChungModel>();
            try
            {
                var lSql = $"select * from TBL_ThongTin_Chung where ID_THONGTIN = {l_Id}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinBangChungModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }


        public int ProcessSql(string status = null, ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            int outValue = -1;
            var conn = openConnection("HDTHUCHIKHCN");
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("p_status", status);
                if (pThongTinChuTaiKhoan != null)
                {
                    param.Add("p_ID_THONGTIN", pThongTinChuTaiKhoan.ID_THONGTIN);
                    param.Add("p_MA_THONGTIN", pThongTinChuTaiKhoan.MA_THONGTIN);
                    param.Add("p_MA_THONGTIN_OLD", pThongTinChuTaiKhoan.MA_THONGTIN_OLD);
                    param.Add("p_ID_QLYC", pThongTinChuTaiKhoan.ID_QLYC);
                    param.Add("p_ID_LOAI_NGHIEP_VU", pThongTinChuTaiKhoan.ID_LOAI_NGHIEP_VU);
                    param.Add("p_TEN_LOAI_NGHIEP_VU", pThongTinChuTaiKhoan.TEN_LOAI_NGHIEP_VU);
                    param.Add("p_TRANGTHAI", pThongTinChuTaiKhoan.TRANGTHAI);
                    param.Add("p_ID_QUYTRINH", pThongTinChuTaiKhoan.ID_QUYTRINH);
                    param.Add("p_NGUOI_TAO", pThongTinChuTaiKhoan.NGUOI_TAO);
                    param.Add("p_NGAY_TAO", pThongTinChuTaiKhoan.NGAY_TAO);
                    param.Add("p_NGUOI_CAPNHAT", pThongTinChuTaiKhoan.NGUOI_CAPNHAT);
                    param.Add("p_NGAY_CAPNHAT", pThongTinChuTaiKhoan.NGAY_CAPNHAT);
                    param.Add("p_MA_DONVI", pThongTinChuTaiKhoan.MA_DONVI);
                    param.Add("p_TEN_DONVI", pThongTinChuTaiKhoan.TEN_DONVI);
                    param.Add("p_MA_DONVI_NHAN", pThongTinChuTaiKhoan.MA_DONVI_NHAN);
                    param.Add("p_TEN_DONVI_NHAN", pThongTinChuTaiKhoan.TEN_DONVI_NHAN);

                    if (pThongTinChuTaiKhoan.NGAY_TAO == DateTime.MinValue || pThongTinChuTaiKhoan.NGAY_CAPNHAT == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NGAY_TAO = DateTime.Now;
                        pThongTinChuTaiKhoan.NGAY_CAPNHAT = DateTime.Now;
                    }

                    /*if (pThongTinChuTaiKhoan.NgayTao == DateTime.MinValue || pThongTinChuTaiKhoan.NgaySua == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NgayTao = DateTime.Now;
                        pThongTinChuTaiKhoan.NgaySua = DateTime.Now;
                    }

                    param.Add("p_NgayTao", pThongTinChuTaiKhoan.NgayTao);
                    param.Add("p_Ngaysua", pThongTinChuTaiKhoan.NgaySua);
                    //param.Add("p_NguoiDungDangNhap", pThongTinChuTaiKhoan.NguoiDungDangNhap);
                    param.Add("p_NguoiDungDangNhap", "SysGiaiNganEB");*/
                }

                param.Add("@p_outValue_from_ttchung", dbType: DbType.Int32, direction: ParameterDirection.Output);

                conn.Open();
                iResult = conn.Execute("sp_TBL_ThongTin_Chung", param, null, null, commandType: CommandType.StoredProcedure);


                if (status == "INSERT")
                {
                    outValue = param.Get<Int32>("@p_outValue_from_ttchung");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            iResult = outValue;
            return iResult;
        }

    }
}
