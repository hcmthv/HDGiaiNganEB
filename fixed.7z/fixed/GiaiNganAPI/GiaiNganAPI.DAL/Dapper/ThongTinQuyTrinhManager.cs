﻿using Dapper;
using GiaiNganAPI.DAL.Core;
using GiaiNganAPI.Entities.Clients;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace GiaiNganAPI.DAL.Dapper
{
    public class ThongTinQuyTrinhManager : dapperDAL
    {
        public static ThongTinQuyTrinhManager Instance { get; } = new ThongTinQuyTrinhManager();

        public List<ThongTinQuyTrinhModel> GetTCThongTinChungTu_Verify()
        {
            List<ThongTinQuyTrinhModel> ThongTinChuTaiKhoanList = new List<ThongTinQuyTrinhModel>();
            try
            {
                var lSql = $"select * from vw_getChungTu_Verify where 1 = 1";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinQuyTrinhModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public List<ThongTinQuyTrinhModel> GetTCThongTinChungTu_Process()
        {
            List<ThongTinQuyTrinhModel> ThongTinChuTaiKhoanList = new List<ThongTinQuyTrinhModel>();
            try
            {
                var lSql = $"select * from vw_getChungTu_Process where 1 = 1";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinQuyTrinhModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public int CapNhatIDQLYC(int l_id, int? l_ID_THONGTIN = null)
        {
            int iResult = -1;
            try
            {
                var lSql = $"update TBL_ThongTin_Chung set ID_QLYC = '{l_id}' where ID_THONGTIN = '{l_ID_THONGTIN}' ";

                using (var conn = openConnection())
                {
                    //iResult = (int)conn.QueryFirst(lSql);
                    iResult = (int)conn.Execute(lSql);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return iResult;
        }

        public int CapNhatTTChuTaiKhoan(int l_id, string l_TrangThai = null, string l_CTK_MaSoThue = null, string l_ChiNhanh = null)
        {
            int iResult = -1;
            try
            {
                var lSql = $"update TBL_ThongTinChuTaiKhoan set TrangThai = '{l_TrangThai}' where 1 = 1  and ID = '{l_id}' and CTK_MaSoThue = '{l_CTK_MaSoThue}' and ChiNhanh = '{l_ChiNhanh}' ";

                using (var conn = openConnection())
                {
                    iResult = (int)conn.Execute(lSql);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return iResult;
        }

        public int CapNhatSoTaiKhoan(int? l_IDChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                var lSql = $" update TBL_SoTaiKhoan set trangthai = (select top 1 TrangThai from TBL_ThongTinChuTaiKhoan where ID ='{l_IDChuTaiKhoan}') where ID_ChuTaiKhoan = '{l_IDChuTaiKhoan}' ";

                using (var conn = openConnection())
                {
                    //iResult = (int)conn.QueryFirst(lSql);
                    iResult = (int)conn.Execute(lSql);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return iResult;
        }

        public int CapNhatTaiLieu(int? l_id, int? l_IDChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                var lSql = $" update TBL_File set TinhTrang = (select top 1 TrangThai from TBL_ThongTinChuTaiKhoan where ID ='{l_IDChuTaiKhoan}') where IDChuTaiKhoan = '{l_IDChuTaiKhoan}' and ID = '{l_id}' ";

                using (var conn = openConnection())
                {
                    //iResult = (int)conn.QueryFirst(lSql);
                    iResult = (int)conn.Execute(lSql);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return iResult;
        }

        public int ProcessSql_BC(string status = null, ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            int outValue = -1;
            var conn = openConnection("HDTHUCHIKHCN");
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("p_status", status);
                if (pThongTinChuTaiKhoan != null)
                {
                    param.Add("p_ID_THONGTIN", pThongTinChuTaiKhoan.ID_THONGTIN);
                    param.Add("p_MA_THONGTIN", pThongTinChuTaiKhoan.MA_THONGTIN);
                    param.Add("p_MA_THONGTIN_OLD", pThongTinChuTaiKhoan.MA_THONGTIN_OLD);
                    param.Add("p_ID_QLYC", pThongTinChuTaiKhoan.ID_QLYC);
                    param.Add("p_ID_LOAI_NGHIEP_VU", pThongTinChuTaiKhoan.ID_LOAI_NGHIEP_VU);
                    param.Add("p_TEN_LOAI_NGHIEP_VU", pThongTinChuTaiKhoan.TEN_LOAI_NGHIEP_VU);
                    param.Add("p_TRANGTHAI", pThongTinChuTaiKhoan.TRANG_THAI);
                    param.Add("p_ID_QUYTRINH", pThongTinChuTaiKhoan.ID_QUYTRINH);
                    param.Add("p_NGUOI_TAO", pThongTinChuTaiKhoan.NGUOI_TAO);
                    param.Add("p_NGAY_TAO", pThongTinChuTaiKhoan.NGAY_TAO);
                    param.Add("p_NGUOI_CAPNHAT", pThongTinChuTaiKhoan.NGUOI_CAPNHAT);
                    param.Add("p_NGAY_CAPNHAT", pThongTinChuTaiKhoan.NGAY_CAPNHAT);
                    param.Add("p_MA_DONVI", pThongTinChuTaiKhoan.MA_DONVI);
                    param.Add("p_TEN_DONVI", pThongTinChuTaiKhoan.TEN_DONVI);
                    param.Add("p_MA_DONVI_NHAN", pThongTinChuTaiKhoan.MA_DONVI_NHAN);
                    param.Add("p_TEN_DONVI_NHAN", pThongTinChuTaiKhoan.TEN_DONVI_NHAN);

                    if (pThongTinChuTaiKhoan.NGAY_TAO == DateTime.MinValue || pThongTinChuTaiKhoan.NGAY_CAPNHAT == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NGAY_TAO = DateTime.Now;
                        pThongTinChuTaiKhoan.NGAY_CAPNHAT = DateTime.Now;
                    }

                }

                param.Add("@p_outValue_from_ttchung", dbType: DbType.Int32, direction: ParameterDirection.Output);

                conn.Open();
                iResult = conn.Execute("sp_TBL_ThongTin_Chung", param, null, null, commandType: CommandType.StoredProcedure);


                if (status == "INSERT")
                {
                    outValue = param.Get<Int32>("@p_outValue_from_ttchung");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            iResult = outValue;
            return iResult;
        }

        public int ProcessSql(string status = null, ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            var conn = openConnection("HDTHUCHIKHCN");
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("p_status", status);
                if (pThongTinChuTaiKhoan != null)
                {
                    param.Add("p_ID", pThongTinChuTaiKhoan.ID);
                    param.Add("p_CTK_Ten", pThongTinChuTaiKhoan.CTK_Ten);
                    param.Add("p_CTK_TenNuocNgoai", pThongTinChuTaiKhoan.CTK_TenNuocNgoai);
                    param.Add("p_CTK_TenVietTat", pThongTinChuTaiKhoan.CTK_TenVietTat);
                    param.Add("p_CTK_DiaChiTruSo", pThongTinChuTaiKhoan.CTK_DiaChiTruSo);

                    param.Add("p_CTK_DiaChiTruSo_Tinh", pThongTinChuTaiKhoan.CTK_DiaChiTruSo_Tinh);
                    param.Add("p_CTK_DiaChiTruSo_Huyen", pThongTinChuTaiKhoan.CTK_DiaChiTruSo_Huyen);
                    param.Add("p_CTK_DiaChiTruSo_Xa", pThongTinChuTaiKhoan.CTK_DiaChiTruSo_Xa);
                    param.Add("p_CTK_DiaChiTruSo_Duong", pThongTinChuTaiKhoan.CTK_DiaChiTruSo_Duong);
                    param.Add("p_CTK_DiaChiGiaoDich", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich);
                    param.Add("p_CTK_DiaChiGiaoDich_Tinh", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich_Tinh);
                    param.Add("p_CTK_DiaChiGiaoDich_Huyen", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich_Huyen);
                    param.Add("p_CTK_DiaChiGiaoDich_Xa", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich_Xa);
                    param.Add("p_CTK_DiaChiGiaoDich_Duong", pThongTinChuTaiKhoan.CTK_DiaChiGiaoDich_Duong);

                    param.Add("p_CTK_SDTCoDinh", pThongTinChuTaiKhoan.CTK_SDTCoDinh);
                    param.Add("p_CTK_Fax", pThongTinChuTaiKhoan.CTK_Fax);
                    param.Add("p_CTK_Email", pThongTinChuTaiKhoan.CTK_Email);
                    param.Add("p_CTK_MaSoThue", pThongTinChuTaiKhoan.CTK_MaSoThue);
                    param.Add("p_CTK_CuTru", pThongTinChuTaiKhoan.CTK_CuTru);
                    param.Add("p_CTK_GiayPhepHoatDong_So", pThongTinChuTaiKhoan.CTK_GiayPhepHoatDong_So);
                    param.Add("p_CTK_GiayPhepHoatDong_NgayCap", pThongTinChuTaiKhoan.CTK_GiayPhepHoatDong_NgayCap);
                    param.Add("p_CTK_GiayPhepHoatDong_NoiCap", pThongTinChuTaiKhoan.CTK_GiayPhepHoatDong_NoiCap);
                    param.Add("p_CTK_LinhVucKinhDoanh", pThongTinChuTaiKhoan.CTK_LinhVucKinhDoanh);
                    param.Add("p_CTK_DoanhThuGanNhat", pThongTinChuTaiKhoan.CTK_DoanhThuGanNhat);
                    param.Add("p_CTK_LoaiHinhToChuc", pThongTinChuTaiKhoan.CTK_LoaiHinhToChuc);
                    param.Add("p_TCTT_Ten", pThongTinChuTaiKhoan.TCTT_Ten);
                    param.Add("p_TCTT_TenNuocNgoai", pThongTinChuTaiKhoan.TCTT_TenNuocNgoai);
                    param.Add("p_TCTT_TenVietTat", pThongTinChuTaiKhoan.TCTT_TenVietTat);
                    param.Add("p_TCTT_DiaChiTruSo", pThongTinChuTaiKhoan.TCTT_DiaChiTruSo);
                    param.Add("p_TCTT_DiaChiGiaoDich", pThongTinChuTaiKhoan.TCTT_DiaChiGiaoDich);
                    param.Add("p_TCTT_SDTCoDinh", pThongTinChuTaiKhoan.TCTT_SDTCoDinh);
                    param.Add("p_TCTT_Fax", pThongTinChuTaiKhoan.TCTT_Fax);
                    param.Add("p_TCTT_Email", pThongTinChuTaiKhoan.TCTT_Email);
                    param.Add("p_TCTT_MaSoThue", pThongTinChuTaiKhoan.TCTT_MaSoThue);
                    param.Add("p_TCTT_CuTru", pThongTinChuTaiKhoan.TCTT_CuTru);
                    param.Add("p_TCTT_GiayPhepHoatDong_So", pThongTinChuTaiKhoan.TCTT_GiayPhepHoatDong_So);
                    param.Add("p_CTK_GiayPhepHoatDong_Loai", pThongTinChuTaiKhoan.CTK_GiayPhepHoatDong_Loai);
                    param.Add("p_TCTT_GiayPhepHoatDong_NgayCap", pThongTinChuTaiKhoan.TCTT_GiayPhepHoatDong_NgayCap);
                    param.Add("p_TCTT_GiayPhepHoatDong_NoiCap", pThongTinChuTaiKhoan.TCTT_GiayPhepHoatDong_NoiCap);
                    param.Add("p_TCTT_DoanhThuGanNhat", pThongTinChuTaiKhoan.TCTT_DoanhThuGanNhat);
                    param.Add("p_TCTT_NguoiDaiDien_Ten", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_Ten);
                    param.Add("p_TCTT_NguoiDaiDien_CMND", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_CMND);
                    param.Add("p_TCTT_NguoiDaiDien_NgayCap", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_NgayCap);
                    param.Add("p_TCTT_NguoiDaiDien_NoiCap", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_NoiCap);
                    param.Add("p_TCTT_NguoiDaiDien_NgaySinh", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_NgaySinh);
                    param.Add("p_TCTT_NguoiDaiDien_SDT", pThongTinChuTaiKhoan.TCTT_NguoiDaiDien_SDT);
                    param.Add("p_TCTT_VanBanUyQuen", pThongTinChuTaiKhoan.TCTT_VanBanUyQuen);
                    param.Add("p_FATCA_ToChucDuocThanhLap", pThongTinChuTaiKhoan.FATCA_ToChucDuocThanhLap);
                    param.Add("p_FATCA_ToChucCoNguoiKiemSoat", pThongTinChuTaiKhoan.FATCA_ToChucCoNguoiKiemSoat);
                    param.Add("p_FATCA_TCTT_MaGIIN", pThongTinChuTaiKhoan.FATCA_TCTT_MaGIIN);
                    param.Add("p_FATCA_TCTT_ChuaDangKy", pThongTinChuTaiKhoan.FATCA_TCTT_ChuaDangKy);
                    param.Add("p_FATCA_KhongPhai3DoiTuongTren", pThongTinChuTaiKhoan.FATCA_KhongPhai3DoiTuongTren);
                    param.Add("p_TKTienGuiThanhToan", pThongTinChuTaiKhoan.TKTienGuiThanhToan);
                    param.Add("p_TKTienGuiLuyTien", pThongTinChuTaiKhoan.TKTienGuiLuyTien);
                    param.Add("p_TKTienGuiLinhHoat", pThongTinChuTaiKhoan.TKTienGuiLinhHoat);
                    param.Add("p_TKTienGuiTichLuyTuDong", pThongTinChuTaiKhoan.TKTienGuiTichLuyTuDong);
                    param.Add("p_TKTienGuiToiUuThanhKhoan", pThongTinChuTaiKhoan.TKTienGuiToiUuThanhKhoan);
                    param.Add("p_TKTienGuiKhac", pThongTinChuTaiKhoan.TKTienGuiKhac);
                    param.Add("p_SoPhuTK_TanSuatNhan", pThongTinChuTaiKhoan.SoPhuTK_TanSuatNhan);
                    param.Add("p_SoPhuTK_PhuongTienGui", pThongTinChuTaiKhoan.SoPhuTK_PhuongTienGui);
                    param.Add("p_DK_Ibanking", pThongTinChuTaiKhoan.DK_Ibanking);
                    param.Add("p_DK_SMSBanking", pThongTinChuTaiKhoan.DK_SMSBanking);
                    param.Add("p_TrangThai", pThongTinChuTaiKhoan.TrangThai);

                    if (pThongTinChuTaiKhoan.NgayTao == DateTime.MinValue || pThongTinChuTaiKhoan.NgaySua == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NgayTao = DateTime.Now;
                        pThongTinChuTaiKhoan.NgaySua = DateTime.Now;
                    }

                    param.Add("p_NgayTao", pThongTinChuTaiKhoan.NgayTao);
                    param.Add("p_Ngaysua", pThongTinChuTaiKhoan.NgaySua);
                    //param.Add("p_NguoiDungDangNhap", pThongTinChuTaiKhoan.NguoiDungDangNhap);
                    param.Add("p_NguoiDungDangNhap", "SysGiaiNganEB");
                    param.Add("p_ChiNhanh", pThongTinChuTaiKhoan.ChiNhanh);

                    param.Add("p_CIF", pThongTinChuTaiKhoan.CIF);
                    param.Add("p_STK", pThongTinChuTaiKhoan.STK);
                    param.Add("p_Ma_ThongTin", pThongTinChuTaiKhoan.Ma_ThongTin);
                    param.Add("p_ID_QLYC", pThongTinChuTaiKhoan._ID_QLYC);
                }

                param.Add("@p_outValue", dbType: DbType.Int32, direction: ParameterDirection.Output);

                conn.Open();
                iResult = conn.Execute("sp_TBL_ThongTinChuTaiKhoan", param, null, null, commandType: CommandType.StoredProcedure);


                if (status == "INSERT")
                {
                    iResult = param.Get<Int32>("@p_outValue");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return iResult;
        }
    }
}
