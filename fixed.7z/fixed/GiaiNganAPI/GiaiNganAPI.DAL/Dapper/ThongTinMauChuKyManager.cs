﻿using Dapper;
using GiaiNganAPI.DAL.Core;
using GiaiNganAPI.Entities.Clients;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace GiaiNganAPI.DAL.Dapper
{
    public class ThongTinMauChuKyManager : dapperDAL
    {
        public static ThongTinMauChuKyManager Instance { get; } = new ThongTinMauChuKyManager();

        public List<ThongTinMauChuKyModel> GetThongTinMauChuKy(int? l_Id = null)
        {
            List<ThongTinMauChuKyModel> ThongTinChuTaiKhoanList = new List<ThongTinMauChuKyModel>();
            try
            {
                var lSql = $"select * from vw_TBL_ThongTinMauChuKy where IDChuTaiKhoan ={l_Id}";

                using (var conn = openConnection())
                {
                    ThongTinChuTaiKhoanList = conn.Query<ThongTinMauChuKyModel>(lSql).ToList();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return ThongTinChuTaiKhoanList;
        }

        public int ProcessSql(string status = null, ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            int outValue = -1;
            var conn = openConnection();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("p_status", status);
                if (pThongTinChuTaiKhoan != null)
                {
                    param.Add("p_ID", pThongTinChuTaiKhoan.ID);
                    param.Add("p_IDChuTaiKhoan", pThongTinChuTaiKhoan.IDChuTaiKhoan);
                    param.Add("p_HoTen", pThongTinChuTaiKhoan.HoTen);
                    param.Add("p_SoCMND", pThongTinChuTaiKhoan.SoCMND);
                    param.Add("p_NoiCap", pThongTinChuTaiKhoan.NoiCap);
                    param.Add("p_NgayCap", pThongTinChuTaiKhoan.NgayCap);
                    param.Add("p_NgaySinh", pThongTinChuTaiKhoan.NgaySinh);
                    param.Add("p_QuocTich", pThongTinChuTaiKhoan.QuocTich);
                    param.Add("p_DiDong", pThongTinChuTaiKhoan.DiDong);
                    param.Add("p_ChucVu", pThongTinChuTaiKhoan.ChucVu);
                    param.Add("p_QuyetDinhBoNhiemSo", pThongTinChuTaiKhoan.QuyetDinhBoNhiemSo);
                    param.Add("p_DiaChiDKTT", pThongTinChuTaiKhoan.DiaChiDKTT);
                    param.Add("p_DiaChiHienTai", pThongTinChuTaiKhoan.DiaChiHienTai);
                    param.Add("p_SoThiThucNhapCanh", pThongTinChuTaiKhoan.SoThiThucNhapCanh);
                    param.Add("p_ThoiHanThiThuc", pThongTinChuTaiKhoan.ThoiHanThiThuc);
                    param.Add("p_DoiTuong", pThongTinChuTaiKhoan.DoiTuong);
                    param.Add("p_UyQuyen", pThongTinChuTaiKhoan.UyQuyen);
                    param.Add("p_VanBanUyQuyenSo", pThongTinChuTaiKhoan.VanBanUyQuyenSo);
                    param.Add("p_NgayUyQuen", pThongTinChuTaiKhoan.NgayUyQuen);
                    param.Add("p_NguoiDaiDien_KeToanTruong", pThongTinChuTaiKhoan.NguoiDaiDien_KeToanTruong);

                    if (pThongTinChuTaiKhoan.NgayTao == DateTime.MinValue || pThongTinChuTaiKhoan.NgaySua == DateTime.MinValue)
                    {
                        pThongTinChuTaiKhoan.NgayTao = DateTime.Now;
                        pThongTinChuTaiKhoan.NgaySua = DateTime.Now;
                    }

                    param.Add("p_NgayTao", pThongTinChuTaiKhoan.NgayTao);
                    param.Add("p_Ngaysua", pThongTinChuTaiKhoan.NgaySua);
                    //param.Add("p_NguoiDungDangNhap", pThongTinChuTaiKhoan.NguoiDungDangNhap);
                    param.Add("p_NguoiDungDangNhap", "SysGiaiNganEB");
                }

                param.Add("@p_outValue", dbType: DbType.Int32, direction: ParameterDirection.Output);

                conn.Open();
                iResult = conn.Execute("sp_TBL_MauChuKy", param, null, null, commandType: CommandType.StoredProcedure);


                if (status == "INSERT")
                {
                    outValue = param.Get<Int32>("@p_outValue");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            iResult = outValue;
            return iResult;
        }

    }
}
