﻿namespace GiaiNganAPI.Lib
{
    public class AppSettings
    {
        public string HDConnection { get; set; }
        public AppSettings() { }
    }
}
