﻿using Newtonsoft.Json;
using System;
using System.Text;

namespace GiaiNganAPI.Lib
{
    public class Common
    {
        public static Common Instant { get; } = new Common() { };
        public static string ConvertToBase64Encode(dynamic _temp)
        {
            var plainTextBytes = JsonConvert.SerializeObject(_temp);
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(plainTextBytes));
        }

        public static string ConvertToBase64Decode(dynamic _temp)
        {
            var base64EncodedBytes = Convert.FromBase64String(_temp);
            return Encoding.UTF8.GetString(base64EncodedBytes);
        }

        protected string randomText()
        {
            string result = "";
            do
            {
                Random rd = new Random();
                result = Convert.ToString((char)rd.Next(48, 90));//122
            }
            while (result == "" || result == ":" || result == ";" || result == "<" || result == "=" || result == ">" || result == "?" || result == "@");//result == "[" || result == 
            return result;
        }

        protected string TaoMaYC()
        {
            var _randomNumber = new Random();
            string _bnumrand = _randomNumber.Next(1, 9).ToString();
            return "Y" + DateTime.Now.ToString("yyMMddhhmmss") + _bnumrand + randomText();//System.Guid.NewGuid().ToString().Replace("-", string.Empty).Substring(0, 1).ToUpper();
        }
        protected string RecheckMaYC(ref string MaYC, ref string TatCaMaYC)
        {
            do
            {
                MaYC = TaoMaYC() + "IB";
            } while (TatCaMaYC.Contains(MaYC + ";") == true);

            TatCaMaYC += MaYC + ";";
            return MaYC;
        }

        public string getMaYC()
        {
            string TatCaMaYC = string.Empty;
            string MaYC = TaoMaYC() + "IB";
            return RecheckMaYC(ref MaYC, ref TatCaMaYC);
        }




    }
}
