﻿using GiaiNganAPI.DAL.Dapper;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using RequestHelper = GiaiNganAPI.jsonRequest;

namespace GiaNganAPI.Services.Clients
{
    public class ThongTinQuyTrinhService : IThongTinQuyTrinhService
    {
        #region ThongTinQuyTrinh
        public async Task<List<ThongTinQuyTrinhModel>> GetTCThongTinChungTu_Verify()
        {
            return await Task.Run(() => ThongTinQuyTrinhManager.Instance.GetTCThongTinChungTu_Verify());
        }

        public async Task<List<ThongTinQuyTrinhModel>> GetTCThongTinChungTu_Process()
        {
            return await Task.Run(() => ThongTinQuyTrinhManager.Instance.GetTCThongTinChungTu_Process());
        }

        public async Task<int> CapNhatIDQLYC(int l_id, int? l_ID_THONGTIN = null)
        {
            return await Task.Run(() => ThongTinQuyTrinhManager.Instance.CapNhatIDQLYC(l_id, l_ID_THONGTIN));
        }

        public async Task<int> CapNhatTTChuTaiKhoan(int l_id, string l_TrangThai = null, string l_CTK_MaSoThue = null, string l_ChiNhanh = null)
        {
            return await Task.Run(() => ThongTinQuyTrinhManager.Instance.CapNhatTTChuTaiKhoan(l_id, l_TrangThai, l_CTK_MaSoThue, l_ChiNhanh));
        }

        public async Task<int> CapNhatSoTaiKhoan(int? l_IDChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinQuyTrinhManager.Instance.CapNhatSoTaiKhoan(l_IDChuTaiKhoan));
        }
        public async Task<int> CapNhatTaiLieu(int? l_id, int? l_IDChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinQuyTrinhManager.Instance.CapNhatTaiLieu(l_id, l_IDChuTaiKhoan));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinQuyTrinhManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> ProcessSql_BC(string status = null, ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinQuyTrinhManager.Instance.ProcessSql_BC(status, pThongTinChuTaiKhoan));
        }

        // The service-1 area
        public async Task<int> InsertThongTinQuyTrinh(ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null, string webRootPath = null)
        {
            int iResult = -1;
            int Handle_iResult = -1;
            try
            {
                // Pushing data -> Khai.DB                    
                iResult = await ProcessSql_BC("INSERT", pThongTinChuTaiKhoan);
                if (iResult > 0)
                {
                    Handle_iResult = iResult;
                    // Pushing Data -> Khai.DB
                    pThongTinChuTaiKhoan._ID_QLYC = Handle_iResult.ToString();
                    iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);

                    // Value from Khai.DB after that re-update to ID_QLYC field in the thongtin_chung table
                    iResult = await CapNhatIDQLYC(Handle_iResult, pThongTinChuTaiKhoan.ID_THONGTIN);
                    // Changing TrangThai = 'Verify' => 'Process'
                    pThongTinChuTaiKhoan.TrangThai = "PROCESS";
                    iResult = await CapNhatTTChuTaiKhoan(pThongTinChuTaiKhoan.ID, pThongTinChuTaiKhoan.TrangThai, pThongTinChuTaiKhoan.CTK_MaSoThue, pThongTinChuTaiKhoan.ChiNhanh);

                    // Changing TrangThai
                    iResult = await CapNhatSoTaiKhoan(pThongTinChuTaiKhoan.ID);

                    // Updating TrangThai of TaiLieu 
                    List<ThongTinTaiLieuModel> _thongtintailieuList = new List<ThongTinTaiLieuModel>();
                    _thongtintailieuList = ThongTinTaiLieuManager.Instance.GetThongTinTaiLieu(pThongTinChuTaiKhoan.ID);
                    foreach(var thongtintailieu in _thongtintailieuList)
                    {
                        iResult = await CapNhatTaiLieu(thongtintailieu.ID, thongtintailieu.IDChuTaiKhoan);

                        // Push images-data to Khai System
                        Stream imageDataStream = RequestHelper.Request.imageDataStream("C:\\DevPrograms\\Projects Working\\hdbank\\wipaper.pdf");
                        var pathFile = webRootPath + "\\export_Invoice.pdf"; //$"\\{thongtintailieu.TenFile}";
                        var content = RequestHelper.Request.PostMultipart(
                        "http://localhost:5000/api/thongtinquytrinh/uploadfile",
                        new Dictionary<string, object>() {
                        { "ID_THONGTIN", $"{pThongTinChuTaiKhoan.ID_THONGTIN}" },
                        { "MA_THONGTIN", $"{pThongTinChuTaiKhoan.MA_THONGTIN}" },
                        { "ID_QLYC", $"{pThongTinChuTaiKhoan._ID_QLYC}" },
                        { "UuTien", $"{thongtintailieu.UuTien}" },
                        { "DienGiaiFile", $"{thongtintailieu.DienGiaiFile}" },
                        { "MyFile", new RequestHelper.FormFile() { Name = $"{thongtintailieu.TenFile}", ContentType = $"{thongtintailieu.LoaiFile}", FilePath = $"{pathFile}" } },
                        // { "other_file", new RequestHelper.FormFile() { Name = "wipaper.pdf", ContentType = "application/pdf", Stream = imageDataStream } },

                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinQuyTrinh(ThongTinQuyTrinhModel pThongTinChuTaiKhoan = null, string webRootPath = null)
        {
            int iResult = -1;           
            try
            {
                string jsonData = JsonConvert.SerializeObject(new
                {
                    ID_QLYC = pThongTinChuTaiKhoan.ID_QLYC,
                    ID_THONGTIN = pThongTinChuTaiKhoan.ID
                });

                var _resultData = JsonConvert.DeserializeObject<ThongTinQuyTrinhModel>(RequestHelper.Request.Instance.httpPost("http://localhost:5000/api/values/resultFile", jsonData)); // HT KHAI  
                
                pThongTinChuTaiKhoan.TrangThai = _resultData.TRANG_THAI;
                iResult = await CapNhatTTChuTaiKhoan(pThongTinChuTaiKhoan.ID, pThongTinChuTaiKhoan.TrangThai, pThongTinChuTaiKhoan.CTK_MaSoThue, pThongTinChuTaiKhoan.ChiNhanh);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }
        #endregion

        #region ThongTinBangRieng

        #endregion

        #region ThongTinBangChung
        public async Task<List<ThongTinBangChungModel>> GetThongTinBangChung(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinBangChungManager.Instance.GetThongTinBangChung(l_Id));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinBangChungManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }
        #endregion
    }
}
