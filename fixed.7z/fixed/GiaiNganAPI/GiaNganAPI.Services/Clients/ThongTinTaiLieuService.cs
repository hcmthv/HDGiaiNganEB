﻿using GiaiNganAPI.DAL.Dapper;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaNganAPI.Services.Clients
{
    public class ThongTinTaiLieuService : IThongTinTaiLieuService
    {
        public async Task<List<ThongTinTaiLieuModel>> GetThongTinTaiLieu(int? l_Id = null, int? l_UuTien = null)
        {
            return await Task.Run(() => ThongTinTaiLieuManager.Instance.GetThongTinTaiLieu(l_Id, l_UuTien));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinTaiLieuModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinTaiLieuManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinTaiLieu(ThongTinTaiLieuModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinTaiLieu(ThongTinTaiLieuModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinTaiLieu(ThongTinTaiLieuModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }
    }
}
