﻿using GiaiNganAPI.DAL.Dapper;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaNganAPI.Services.Clients
{
    public class ThongTinChuTaiKhoanService : IThongTinChuTaiKhoanService, IThongTinChuSoHuuHuongLoiService
    {
        public async Task<List<ThongTinChuTaiKhoanModel>> GetTCThongTinChuTaiKhoan()
        {
            return await Task.Run(() => ThongTinChuTaiKhoanManager.Instance.GetTCThongTinChuTaiKhoan());
        }

        public async Task<List<ThongTinChuTaiKhoanModel>> GetThongTinChuTaiKhoan(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinChuTaiKhoanManager.Instance.GetThongTinChuTaiKhoan(l_Id));
        }

        public async Task<List<ThongTinChuTaiKhoanModel>> GetThongTinChuSoTaiKhoan(int? l_Id = null, string l_SoTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinChuTaiKhoanManager.Instance.GetThongTinChuSoTaiKhoan(l_Id, l_SoTaiKhoan));
        }

        #region ThongTinChuTaiKhoan
        public async Task<int> ProcessSql(string status = null, ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinChuTaiKhoanManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinChuTaiKhoan(ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            int handle_IDChuTaiKhoan = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
                handle_IDChuTaiKhoan = iResult;
                foreach (var _thongtinchusohuuhuongloi in pThongTinChuTaiKhoan.ThongTinChuSoHuuHuongLoi)
                {
                    _thongtinchusohuuhuongloi.ID_ChuTaiKhoan = handle_IDChuTaiKhoan;
                    iResult = await ProcessSql("INSERT", _thongtinchusohuuhuongloi);
                }

                foreach (var _thongtinmauchuky in pThongTinChuTaiKhoan.ThongTinMauChuKy)
                {
                    _thongtinmauchuky.IDChuTaiKhoan = handle_IDChuTaiKhoan;
                    iResult = await ProcessSql("INSERT", _thongtinmauchuky);
                }

                pThongTinChuTaiKhoan.ThongTinUyQuyen.ID_ChuTaiKhoan = handle_IDChuTaiKhoan;
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan.ThongTinUyQuyen);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return handle_IDChuTaiKhoan;
        }

        public async Task<int> UpdateThongTinChuTaiKhoan(ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
                foreach (var _thongtinchusohuuhuongloi in pThongTinChuTaiKhoan.ThongTinChuSoHuuHuongLoi)
                {
                    //_thongtinchusohuuhuongloi.ID_ChuTaiKhoan = iResult;
                    iResult = await ProcessSql("UPDATE", _thongtinchusohuuhuongloi);
                }

                foreach (var _thongtinmauchuky in pThongTinChuTaiKhoan.ThongTinMauChuKy)
                {
                    //_thongtinchusohuuhuongloi.ID_ChuTaiKhoan = iResult;
                    iResult = await ProcessSql("UPDATE", _thongtinmauchuky);
                }

                iResult = await ProcessSql("UPDATE", pThongTinChuTaiKhoan.ThongTinUyQuyen);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> DeleteThongTinChuTaiKhoan(ThongTinChuTaiKhoanModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }
        #endregion

        #region ThongTaiChuSoHuuHuongLoi
        public async Task<List<ThongTinChuSoHuuHuongLoiModel>> GetThongTinChuSoHuuHuongLoi(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinChuSoHuuHuongLoiManager.Instance.GetThongTinChuSoHuuHuongLoi(l_Id));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinChuSoHuuHuongLoiManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }
        #endregion

        #region ThongTinMauChuKy
        public async Task<List<ThongTinMauChuKyModel>> GetThongTinMauChuKy(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinMauChuKyManager.Instance.GetThongTinMauChuKy(l_Id));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinMauChuKyManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }
        #endregion

        #region ThongTinUyQuyen
        public async Task<List<ThongTinUyQuyenModel>> GetThongTinUyQuyen(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinUyQuyenManager.Instance.GetThongTinUyQuyen(l_Id));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinUyQuyenManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }
        #endregion
    }
}
