﻿using GiaiNganAPI.DAL.Dapper;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaNganAPI.Services.Clients
{
    public class ThongTinChuSoHuuHuongLoiService : IThongTinChuSoHuuHuongLoiService
    {
        public async Task<List<ThongTinChuSoHuuHuongLoiModel>> GetThongTinChuSoHuuHuongLoi(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinChuSoHuuHuongLoiManager.Instance.GetThongTinChuSoHuuHuongLoi(l_Id));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinChuSoHuuHuongLoiManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinChuSoHuuHuongLoi(ThongTinChuSoHuuHuongLoiModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }
    }
}
