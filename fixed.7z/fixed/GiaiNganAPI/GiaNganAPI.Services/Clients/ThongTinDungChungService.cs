﻿using GiaiNganAPI.DAL.Dapper;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaNganAPI.Services.Clients
{
    public class ThongTinDungChungService : IThongTinDungChungService
    {
        #region Khu Vuc
        public async Task<List<ThongTinTinhModel>> GetThongTinTinh(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinTinh(l_Id));
        }

        public async Task<List<ThongTinHuyenModel>> GetThongTinHuyen(int? l_PROVINCE_ID = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinHuyen(l_PROVINCE_ID));
        }

        public async Task<List<ThongTinXaModel>> GetThongTinXa(int? l_DISTRICT_ID = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinXa(l_DISTRICT_ID));
        }

        public async Task<List<ThongTinDuongModel>> GetThongTinDuong(int? l_PROVINCE_ID = null, int? l_DISTRICT_ID = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinDuong(l_PROVINCE_ID, l_DISTRICT_ID));
        }
        #endregion


        public async Task<List<ThongTinChiNhanhModel>> GetThongTinChiNhanh(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinChiNhanh(l_Id));
        }

        public async Task<List<ThongTinSoTaiKhoanModel>> GetThongTinCIF(int? l_Id = null, string l_MaChiNhanh = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinCIF(l_Id, l_MaChiNhanh));
        }

        public async Task<List<ThongTinSoTaiKhoanModel>> GetThongTinTienTe(int? l_Id = null, string l_MaChiNhanh = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinTienTe(l_Id, l_MaChiNhanh));
        }

        public async Task<List<ThongTinSoTaiKhoanModel>> GetThongTinSoTaiKhoan(int? l_Id = null, string l_MaChiNhanh = null, string l_TienTe = null, string l_CIF = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinSoTaiKhoan(l_Id, l_MaChiNhanh, l_TienTe, l_CIF));
        }

        public async Task<List<ThongTinThamSoModel>> GetThongTinThamSo(int? l_Id = null, string l_MaChiNhanh = null)
        {
            return await Task.Run(() => ThongTinDungChungManager.Instance.GetThongTinThamSo(l_Id, l_MaChiNhanh));
        }

    }
}

