﻿using GiaiNganAPI.DAL.Dapper;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaNganAPI.Services.Clients
{
    public class ThongTinBangChungService : IThongTinBangChungService
    {
        public async Task<List<ThongTinBangChungModel>> GetID_QLYCThongTinBangChung(int? l_ID_QLYC = null)
        {
            return await Task.Run(() => ThongTinBangChungManager.Instance.GetID_QLYCThongTinBangChung(l_ID_QLYC));
        }
        public async Task<List<ThongTinBangChungModel>> GetThongTinBangChung(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinBangChungManager.Instance.GetThongTinBangChung(l_Id));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinBangChungManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinBangChung(ThongTinBangChungModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }

    }
}
