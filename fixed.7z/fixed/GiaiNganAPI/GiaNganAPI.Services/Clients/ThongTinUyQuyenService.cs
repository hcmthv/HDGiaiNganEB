﻿using GiaiNganAPI.DAL.Dapper;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaNganAPI.Services.Clients
{
    public class ThongTinUyQuyenService : IThongTinUyQuyenService
    {
        public async Task<List<ThongTinUyQuyenModel>> GetThongTinUyQuyen(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinUyQuyenManager.Instance.GetThongTinUyQuyen(l_Id));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinUyQuyenManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinUyQuyen(ThongTinUyQuyenModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }

    }
}
