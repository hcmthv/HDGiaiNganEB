﻿using GiaiNganAPI.DAL.Dapper;
using GiaiNganAPI.Entities.Clients;
using GiaiNganAPI.Interfaces.Clients;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GiaNganAPI.Services.Clients
{
    public class ThongTinMauChuKyService : IThongTinMauChuKyService
    {
        public async Task<List<ThongTinMauChuKyModel>> GetThongTinMauChuKy(int? l_Id = null)
        {
            return await Task.Run(() => ThongTinMauChuKyManager.Instance.GetThongTinMauChuKy(l_Id));
        }

        public async Task<int> ProcessSql(string status = null, ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            return await Task.Run(() => ThongTinMauChuKyManager.Instance.ProcessSql(status, pThongTinChuTaiKhoan));
        }

        public async Task<int> InsertThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            int iResult = -1;
            try
            {
                iResult = await ProcessSql("INSERT", pThongTinChuTaiKhoan);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return iResult;
        }

        public async Task<int> UpdateThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("UPDATE", pThongTinChuTaiKhoan);
        }

        public async Task<int> DeleteThongTinMauChuKy(ThongTinMauChuKyModel pThongTinChuTaiKhoan = null)
        {
            return await ProcessSql("DELETE", pThongTinChuTaiKhoan);
        }

    }
}
