﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Hosting;

namespace GiaNganAPI.Services.Common.Upload
{
    public class LocalUploadService : IUploadService
    {
        private readonly string _rootPath;
        private readonly string _rootDomain;
        private IConfiguration _configuration;
        private readonly IHostingEnvironment _webHostEnvironment;

        private string[] validImages =
        {
            "image/png", "image/jpeg","image/jpg", "image/gif","application/doc","application/pdf","text/plain"
        };
        public LocalUploadService(IConfiguration configuration, IHostingEnvironment hostEnvironment)
        {
            _configuration = configuration;
            var configSection = _configuration.GetSection("AppSettings");
            _rootPath = configSection.GetValue<string>("UploadRootPath");
            _rootDomain = configSection.GetValue<string>("UploadRootDomain");
            _webHostEnvironment = hostEnvironment;
        }
        //data:;base64,
        //data:application/x-msdownload;base64,TVpQAAIA
        //data:image/png;base64,iVBORw0KG
        //data:text/plain;base64,MS4gQ
        //data:application/pdf;base64,JVBERi0xLj

        public async Task<(bool status, string filePath, string refMsg)> UploadPhoto(string fileName, string fileType, string base64Data, string specifiedFolder = null)
        {
            try
            {
                if (string.IsNullOrEmpty(fileName))
                {
                    return (false, null, "Filename is invalid");
                }
                if (string.IsNullOrEmpty(fileType) || !validImages.Contains(fileType))
                {
                    return (false, null, "File type [" + fileType + "] does not supported");
                }
                string uploadPath = _rootPath;
                if (!string.IsNullOrEmpty(specifiedFolder))
                {
                    uploadPath = Path.Combine(uploadPath, specifiedFolder);
                    if (!Directory.Exists(uploadPath))
                    {
                        Directory.CreateDirectory(uploadPath);
                    }
                }
                string[] sData = base64Data.Split(';');
                var base64Array = Convert.FromBase64String(sData[1].Replace("base64,", ""));

                //DateTime.Now.ToString("yyyyMMddHHmmss");
                //string fileExt = FileUtils.GetImageFormat(sData[0].Split(':')[1]);
                //string fileName = Guid.NewGuid() + fileExt;

                await File.WriteAllBytesAsync(Path.Combine(uploadPath, fileName), base64Array);
                string fullPath = _rootDomain + specifiedFolder + "/" + fileName;
                return (true, fullPath, "Uploaded successfully");
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message);
            }
        }


        public async Task<(bool status, string filePath, string refMsg)> UploadDocument(string fileName, string fileType, IFormFile fileData,
            string specifiedFolder = null)
        {
            try
            {
                if (string.IsNullOrEmpty(fileName))
                {
                    return (false, null, "Filename is invalid");
                }
                if (string.IsNullOrEmpty(fileType) || !validImages.Contains(fileType))
                {
                    return (false, null, "File type [" + fileType + "] does not supported");
                }

                string uploadPath =  _rootPath == "webHostEnvironment" ? _webHostEnvironment.ContentRootPath + "\\upload\\" : _rootPath;
                if (!string.IsNullOrEmpty(specifiedFolder))
                {
                    uploadPath = Path.Combine(uploadPath, specifiedFolder);
                    if (!Directory.Exists(uploadPath))
                    {
                        Directory.CreateDirectory(uploadPath);
                    }
                }

                var uniqueFileName = fileName; // GetUniqueFileName(fileData.FileName);
                var filePath = Path.Combine(uploadPath, uniqueFileName);
                await fileData.CopyToAsync(new FileStream(filePath, FileMode.Create));

                string fullPath = _rootDomain + specifiedFolder + "/" + fileName;
                return (true, fullPath, "Uploaded successfully");
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message);
            }
        }

        private string GetUniqueFileName(string fileName)
        {
            fileName = Path.GetFileName(fileName);

            return Path.GetFileNameWithoutExtension(fileName)
                      + "_"
                      + Guid.NewGuid().ToString().Substring(0, 4)
                      + Path.GetExtension(fileName);

        }
    }
}
