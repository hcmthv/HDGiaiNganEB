﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace GiaNganAPI.Services.Common.Upload
{
    public interface IUploadService
    {
        Task<(bool status, string filePath, string refMsg)> UploadPhoto(string fileName, string fileType, string base64Data,
            string specifiedFolder = null);

        Task<(bool status, string filePath, string refMsg)> UploadDocument(string fileName, string fileType, IFormFile fileData,
            string specifiedFolder = null);

    }
}
