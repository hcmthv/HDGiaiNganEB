﻿namespace GiaiNganAPI.Entities
{
    public class processResultModel
    {
        public int Result { get; set; }
        public int outValue { get; set; }

    }
}
