﻿namespace GiaiNganAPI.Entities.Common
{
    public class Constant
    {
        public static string FORMAT_DATE_YMD = "yyyyMMdd";
        public static string FORMAT_DATE_SHORT = "yyyy-MM-dd";
        public static string FORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss";
    }
}
