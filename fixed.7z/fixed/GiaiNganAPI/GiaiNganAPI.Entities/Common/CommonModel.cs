﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace GiaiNganAPI.Entities.Common
{
    public class FileUploadData
    {
        [JsonProperty("file_name")]
        public string FileName { get; set; }
        [JsonProperty("file_type")]
        public string FileType { get; set; }
        public string Value { get; set; }
    }

    public class UploadFileModel
    {
        public string FileName { set; get; }
        public string FileType { set; get; }
        public IFormFile MyFile { set; get; }
    }

}
