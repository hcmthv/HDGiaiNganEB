﻿using System;

namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinHuyenModel
    {
        public int DISTRICT_ID { get; set; }
        public string DISTRICT_NAME { get; set; }
        public string PROVINCE_ID { get; set; }
        public DateTime Created { get; set; }
    }
}
