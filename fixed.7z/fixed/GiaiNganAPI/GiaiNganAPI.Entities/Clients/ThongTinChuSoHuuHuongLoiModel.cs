﻿using System;

namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinChuSoHuuHuongLoiModel
    {

        public int ID { get; set; }
        public int ID_ChuTaiKhoan { get; set; }
        public string LoaiChuSoHuu { get; set; }
        public string HoTen { get; set; }
        public string CMND { get; set; }
        public DateTime NgayCap { get; set; }
        public string NoiCap { get; set; }
        public DateTime NgaySinh { get; set; }
        public string QuocTich { get; set; }
        public string DiaChiThuongTru { get; set; }

        public string DiaChiThuongTru_Tinh { get; set; }
        public string DiaChiThuongTru_Huyen { get; set; }
        public string DiaChiThuongTru_Xa { get; set; }
        public string DiaChiThuongTru_Duong { get; set; }
        public string DiaChiLienLac { get; set; }
        public string DiaChiLienLac_Tinh { get; set; }
        public string DiaChiLienLac_Huyen { get; set; }
        public string DiaChiLienLac_Xa { get; set; }
        public string DiaChiLienLac_Duong { get; set; }

        public string DiDong { get; set; }
        public string NgheNghiep { get; set; }
        public string ChucVu { get; set; }
        public string CongTy { get; set; }
        public string TenDoanhNghiep { get; set; }
        public string DiaChiTruSo { get; set; }
        public string DienThoaiCoDinh { get; set; }
        public string Fax { get; set; }

        public string TrucTiepGianTiep { get; set; }
        public string TenToChucSoHuu { get; set; }
        public string TyLeSoHuu { get; set; }
        public string SoGPHD { get; set; }
        public string QuocGiaDatTruSoChinh { get; set; }

        public DateTime NgayTao { get; set; }
        public DateTime NgaySua { get; set; }
        public string NguoiDungDangNhap { get; set; }
    }
}
