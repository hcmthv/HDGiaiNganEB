﻿namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinSoTaiKhoanModel
    {
        public int ID { get; set; }
        public string CIF { get; set; }
        public string STK { get; set; }
        public string LoaiTien { get; set; }
        public int ID_ChuTaiKhoan { get; set; }
        public string TenChuTaiKhoan { get; set; }
        public string ChiNhanh { get; set; }
        public string TrangThai { get; set; }
    }
}
