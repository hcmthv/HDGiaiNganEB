﻿namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinDuongModel
    {
        public int ID { get; set; }
        public string STR_NAME { get; set; }
        public int PROVINCE_ID { get; set; }
        public string DISTRICT_ID { get; set; }
    }
}
