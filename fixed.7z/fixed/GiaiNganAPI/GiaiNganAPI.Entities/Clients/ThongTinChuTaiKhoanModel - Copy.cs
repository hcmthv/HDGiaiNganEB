﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinChuTaiKhoanModel
    {

        [Required]
        public int ID { get; set; }

		[StringLength(200)]
		public string TenChuTaiKhoan{ get; set; }

		[StringLength(200)]
		public string TenChuTaiKhoan_NuocNgoai { get; set; }

		[StringLength(200)]
		public string TenChuTaiKhoan_VietTat { get; set; }
		
		public string DiaChiTruSo { get; set; }		
		public string DaiChiGiaoDich { get; set; }
		[StringLength(200)]
		public string SDTCoDinh { get; set; }
		[StringLength(50)]
		public string Fax { get; set; }

		[StringLength(100)]
		public string Email { get; set; }
		[StringLength(50)]
		public string MaSoThue { get; set; }
		[StringLength(50)]
		public string CuTru { get; set; }

		[StringLength(200)]
		public string GiayPhepHoatDong_So { get; set; }
	
		public DateTime GiayPhepHoatDong_NgayCap { get; set; }
	
		public string GiayPhepHoatDong_NoiCap { get; set; }
		
		public string LinhVucKinhDoanh { get; set; }
		
		public string DoanhThuGanNhat { get; set; }

		[StringLength(50)]
		public string LoaiHinhToChuc { get; set; }

		[StringLength(50)]
		public string TrangThai { get; set; }
						
		public DateTime NgayTao { get; set; }		
		public DateTime Ngaysua { get; set; }

		/*[StringLength(50)]
		public string NguoiDungDangNhap { get; set; } */
	}
}


