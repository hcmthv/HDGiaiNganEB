﻿namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinXaModel
    {
        public int WARD_ID { get; set; }
        public string WARD_NAME { get; set; }
        public string DISTRICT_ID { get; set; }
    }
}
