﻿using System;

namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinQuyTrinhModel
    {
        #region Thong Tin Chu Tai Khoan
        public int ID { get; set; }
        public string CTK_Ten { get; set; }
        public string CTK_TenNuocNgoai { get; set; }
        public string CTK_TenVietTat { get; set; }
        public string CTK_DiaChiTruSo { get; set; }
        public string CTK_DiaChiTruSo_Tinh { get; set; }
        public string CTK_DiaChiTruSo_Huyen { get; set; }
        public string CTK_DiaChiTruSo_Xa { get; set; }
        public string CTK_DiaChiTruSo_Duong { get; set; }
        public string CTK_DiaChiGiaoDich { get; set; }
        public string CTK_DiaChiGiaoDich_Tinh { get; set; }
        public string CTK_DiaChiGiaoDich_Huyen { get; set; }
        public string CTK_DiaChiGiaoDich_Xa { get; set; }
        public string CTK_DiaChiGiaoDich_Duong { get; set; }
        public string CTK_SDTCoDinh { get; set; }
        public string CTK_Fax { get; set; }
        public string CTK_Email { get; set; }
        public string CTK_MaSoThue { get; set; }
        public string CTK_CuTru { get; set; }
        public string CTK_GiayPhepHoatDong_So { get; set; }
        public DateTime CTK_GiayPhepHoatDong_NgayCap { get; set; }
        public string CTK_GiayPhepHoatDong_NoiCap { get; set; }
        public string CTK_LinhVucKinhDoanh { get; set; }
        public string CTK_DoanhThuGanNhat { get; set; }
        public string CTK_LoaiHinhToChuc { get; set; }
        public string TCTT_Ten { get; set; }
        public string TCTT_TenNuocNgoai { get; set; }
        public string TCTT_TenVietTat { get; set; }
        public string TCTT_DiaChiTruSo { get; set; }
        public string TCTT_DiaChiGiaoDich { get; set; }
        public string TCTT_SDTCoDinh { get; set; }
        public string TCTT_Fax { get; set; }
        public string TCTT_Email { get; set; }
        public string TCTT_MaSoThue { get; set; }
        public string TCTT_CuTru { get; set; }
        public string TCTT_GiayPhepHoatDong_So { get; set; }
        public DateTime TCTT_GiayPhepHoatDong_NgayCap { get; set; }
        public string TCTT_GiayPhepHoatDong_NoiCap { get; set; }
        public string TCTT_DoanhThuGanNhat { get; set; }
        public string TCTT_NguoiDaiDien_Ten { get; set; }
        public string TCTT_NguoiDaiDien_CMND { get; set; }
        public DateTime TCTT_NguoiDaiDien_NgayCap { get; set; }
        public string TCTT_NguoiDaiDien_NoiCap { get; set; }
        public DateTime TCTT_NguoiDaiDien_NgaySinh { get; set; }
        public string TCTT_NguoiDaiDien_SDT { get; set; }

        public string TCTT_VanBanUyQuen { get; set; }
        public string FATCA_ToChucDuocThanhLap { get; set; }
        public string FATCA_ToChucCoNguoiKiemSoat { get; set; }
        public string FATCA_TCTT_MaGIIN { get; set; }
        public string FATCA_TCTT_ChuaDangKy { get; set; }
        public string FATCA_KhongPhai3DoiTuongTren { get; set; }
        public string TKTienGuiThanhToan { get; set; }
        public string TKTienGuiLuyTien { get; set; }
        public string TKTienGuiLinhHoat { get; set; }
        public string TKTienGuiTichLuyTuDong { get; set; }
        public string TKTienGuiToiUuThanhKhoan { get; set; }
        public string TKTienGuiKhac { get; set; }
        public string SoPhuTK_TanSuatNhan { get; set; }
        public string SoPhuTK_PhuongTienGui { get; set; }
        public string DK_Ibanking { get; set; }
        public string DK_SMSBanking { get; set; }
        public string TrangThai { get; set; }

        public DateTime NgayTao { get; set; }
        public DateTime NgaySua { get; set; }
        public string NguoiDungDangNhap { get; set; }

        public string ChiNhanh { get; set; }
        public string CIF { get; set; }
        public string STK { get; set; }
        public string Ma_ThongTin { get; set; }

        public string _ID_QLYC { get; set; }

        public string CTK_GiayPhepHoatDong_Loai { get; set; }
        #endregion

        #region Thong Tin Bang Chung
        public int ID_THONGTIN { get; set; }
        public string MA_THONGTIN { get; set; }
        public string MA_THONGTIN_OLD { get; set; }
        public string ID_QLYC { get; set; }
        public int ID_LOAI_NGHIEP_VU { get; set; }
        public string TEN_LOAI_NGHIEP_VU { get; set; }
        public string TRANG_THAI { get; set; }
        public int ID_QUYTRINH { get; set; }
        public string NGUOI_TAO { get; set; }
        public DateTime NGAY_TAO { get; set; }
        public string NGUOI_CAPNHAT { get; set; }
        public DateTime NGAY_CAPNHAT { get; set; }
        public int MA_DONVI { get; set; }
        public string TEN_DONVI { get; set; }
        public int MA_DONVI_NHAN { get; set; }
        public string TEN_DONVI_NHAN { get; set; }
        #endregion

    }

}
