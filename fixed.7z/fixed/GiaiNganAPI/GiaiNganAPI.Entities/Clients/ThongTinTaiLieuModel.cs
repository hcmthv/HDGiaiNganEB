﻿using System;

namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinTaiLieuModel : Common.UploadFileModel
    {
        public int ID { get; set; }
        public int IDChuTaiKhoan { get; set; }
        public string TenFile { get; set; }
        public string DuongDan { get; set; }
        public string TinhTrang { get; set; }

        public int UuTien { get; set; }
        public string DienGiaiFile { get; set; }

        public DateTime NgayTao { get; set; }
        public DateTime NgaySua { get; set; }

        public string NguoiDungDangNhap { get; set; }

        public string LoaiFile { get; set; }

        public string MA_THONGTIN { set; get; }
        public string ID_QLYC { set; get; }
    }
}
