﻿namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinTinhModel
    {
        public int PROVINCE_ID { get; set; }
        public string PROVINCE_NAME { get; set; }
        public string REGION_ID { get; set; }
    }
}
