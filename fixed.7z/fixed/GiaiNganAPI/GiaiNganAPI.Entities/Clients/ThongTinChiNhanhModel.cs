﻿namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinChiNhanhModel
    {
        public string MaChiNhanh { get; set; }
        public string TenChiNhanh { get; set; }
        public string TenTP { get; set; }
        public string DiaChi { get; set; }
        public string DienThoai { get; set; }
    }
}
