﻿using System;

namespace GiaiNganAPI.Entities.Clients
{

    public class ThongTinBangChungModel
    {
        public int ID_THONGTIN { get; set; }
        public string MA_THONGTIN { get; set; }
        public string MA_THONGTIN_OLD { get; set; }
        public string ID_QLYC { get; set; }
        public int ID_LOAI_NGHIEP_VU { get; set; }
        public string TEN_LOAI_NGHIEP_VU { get; set; }
        public string TRANGTHAI { get; set; }
        public int ID_QUYTRINH { get; set; }
        public string NGUOI_TAO { get; set; }
        public DateTime NGAY_TAO { get; set; }
        public string NGUOI_CAPNHAT { get; set; }
        public DateTime NGAY_CAPNHAT { get; set; }
        public int MA_DONVI { get; set; }
        public string TEN_DONVI { get; set; }
        public int MA_DONVI_NHAN { get; set; }
        public string TEN_DONVI_NHAN { get; set; }
    }
}
