﻿using System;

namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinThamSoModel
    {
        public int ID { get; set; }
        public string Nhom { get; set; }
        public string IDNhomCha { get; set; }
        public string Ten { get; set; }
        public string GiaTri { get; set; }
        public DateTime NgayTao { get; set; }
    }
}
