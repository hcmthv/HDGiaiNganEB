﻿using System;

namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinUyQuyenModel
    {
        public int ID { get; set; }
        public int ID_ChuTaiKhoan { get; set; }
        public string HoTen { get; set; }
        public string TenTiengAnh { get; set; }
        public string SoCMND { get; set; }
        public string GiayPhepHoatDong_So { get; set; }
        public string DiaChiTT { get; set; }
        public string LoaiTaiSan { get; set; }
        public string GiaTri { get; set; }
        public string NoiDung { get; set; }
        public DateTime NgayUyQuyen { get; set; }
        public string SoDinhDanhUyQuyen { get; set; }
        public string TenNguoiHuongLoi { get; set; }
        public DateTime NgayTao { get; set; }
        public DateTime NgaySua { get; set; }
        public string NguoiDungDangNhap { get; set; }
    }
}
