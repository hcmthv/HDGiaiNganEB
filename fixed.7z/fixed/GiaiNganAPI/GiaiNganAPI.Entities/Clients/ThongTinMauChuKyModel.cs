﻿using System;

namespace GiaiNganAPI.Entities.Clients
{
    public class ThongTinMauChuKyModel
    {
        public int ID { get; set; }
        public int IDChuTaiKhoan { get; set; }
        public string HoTen { get; set; }
        public string SoCMND { get; set; }
        public string NoiCap { get; set; }
        public DateTime NgayCap { get; set; }
        public DateTime NgaySinh { get; set; }
        public string QuocTich { get; set; }
        public string DiDong { get; set; }
        public string ChucVu { get; set; }
        public string QuyetDinhBoNhiemSo { get; set; }
        public string DiaChiDKTT { get; set; }
        public string DiaChiHienTai { get; set; }
        public string SoThiThucNhapCanh { get; set; }
        public string ThoiHanThiThuc { get; set; }
        public string DoiTuong { get; set; }
        public string UyQuyen { get; set; }
        public string VanBanUyQuyenSo { get; set; }
        public DateTime NgayUyQuen { get; set; }
        public string NguoiDaiDien_KeToanTruong { get; set; }
        public DateTime NgayTao { get; set; }
        public DateTime NgaySua { get; set; }
        public string NguoiDungDangNhap { get; set; }
    }
}
